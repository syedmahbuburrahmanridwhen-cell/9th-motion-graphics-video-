import React, { useEffect, useState } from "react";
import { AbsoluteFill, Sequence, continueRender, delayRender } from "remotion";
import "./fonts/hind-siliguri.css";
import { theme } from "./theme";
import { SCENES, sceneDur, sceneStart } from "./timeline";
import { SceneProvider, Sfx } from "./motion";
import { Bg, CutWipe, Grade, Grain, PreviewAudio, SceneShell, Vignette } from "./components";
import { Hook } from "./scenes/Hook";
import { Overview } from "./scenes/Overview";
import { Framer } from "./scenes/Framer";
import { Dora } from "./scenes/Dora";
import { Hostinger } from "./scenes/Hostinger";
import { Recap } from "./scenes/Recap";
import { Follow } from "./scenes/Follow";

const COMPONENTS = [Hook, Overview, Framer, Dora, Hostinger, Recap, Follow];

const useFonts = () => {
  const [handle] = useState(() => delayRender("fonts"));
  useEffect(() => {
    Promise.all([
      document.fonts.load('700 60px "Hind Siliguri"', "আকখ"),
      document.fonts.load('700 60px "Hind Siliguri"', "Abc123"),
      document.fonts.load('600 60px "Hind Siliguri"', "আকখAbc"),
      document.fonts.load('500 60px "Hind Siliguri"', "আকখAbc"),
    ]).finally(() => continueRender(handle));
  }, [handle]);
};

export const Main: React.FC = () => {
  useFonts();
  return (
    <AbsoluteFill style={{ background: theme.colors.bg, fontFamily: theme.fonts.display }}>
      {/* layer 1: background mesh */}
      <Bg />
      {/* layers 2–3: assets + graphics (per scene) */}
      {SCENES.map((s, i) => {
        const C = COMPONENTS[i];
        return (
          <Sequence key={s.id} from={sceneStart(i)} durationInFrames={sceneDur(i)}>
            <SceneProvider index={i}>
              <SceneShell>
                <C />
              </SceneShell>
            </SceneProvider>
          </Sequence>
        );
      })}
      {/* scene cuts: wipe panel + soft swipe sound */}
      {SCENES.slice(1).map((s, k) => (
        <React.Fragment key={s.id}>
          <CutWipe cut={sceneStart(k + 1)} />
          <Sequence from={0} durationInFrames={sceneStart(k + 1) + 30} layout="none">
            <Sfx name="swipe" at={sceneStart(k + 1) - 15} gain={0.9 + (k % 2) * 0.1} rate={1 + (k % 3) * 0.04} />
          </Sequence>
        </React.Fragment>
      ))}
      {/* layers 4–5: grade, grain, vignette */}
      <Grade />
      <Grain />
      <Vignette />
      <PreviewAudio />
    </AbsoluteFill>
  );
};
