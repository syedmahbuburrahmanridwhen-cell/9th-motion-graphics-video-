// timeline.ts — every frame number in the video is derived from the SRT cues.
import { SRT } from "./script";

export const FPS = 30;
export const WIDTH = 1920;
export const HEIGHT = 1080;
/** Visual cuts land this many frames BEFORE the cue that starts the next scene. */
export const CUT_LEAD = 6;

export type Cue = { n: number; start: number; end: number; text: string };

const toSec = (t: string) => {
  const m = t.trim().match(/(\d+):(\d+):(\d+)[,.](\d+)/)!;
  return +m[1] * 3600 + +m[2] * 60 + +m[3] + +m[4] / 1000;
};

export const cues: Cue[] = SRT.trim()
  .split(/\r?\n\s*\r?\n/)
  .map((block) => {
    const lines = block.trim().split(/\r?\n/);
    const [a, b] = lines[1].split("-->");
    return { n: +lines[0], start: toSec(a), end: toSec(b), text: lines.slice(2).join(" ") };
  });

const cue = (n: number) => cues.find((c) => c.n === n)!;
export const cueFrame = (n: number) => Math.round(cue(n).start * FPS);
export const cueEndFrame = (n: number) => Math.round(cue(n).end * FPS);
export const TOTAL_FRAMES = Math.ceil(cues[cues.length - 1].end * FPS);

/** Scenes are split on cue boundaries (first/last cue numbers). */
export const SCENES = [
  { id: "hook", first: 1, last: 2 },
  { id: "overview", first: 3, last: 4 },
  { id: "framer", first: 5, last: 10 },
  { id: "dora", first: 11, last: 14 },
  { id: "hostinger", first: 15, last: 18 },
  { id: "recap", first: 19, last: 21 },
  { id: "follow", first: 22, last: 24 },
] as const;

export const sceneStart = (i: number) => (i === 0 ? 0 : cueFrame(SCENES[i].first) - CUT_LEAD);
export const sceneEnd = (i: number) => (i === SCENES.length - 1 ? TOTAL_FRAMES : sceneStart(i + 1));
export const sceneDur = (i: number) => sceneEnd(i) - sceneStart(i);

/** Local frame (inside scene i) of a point `frac` (0..1) through cue `n`. */
export const localAt = (i: number, n: number, frac = 0) => {
  const s = cueFrame(n);
  const e = cueEndFrame(n);
  return Math.round(s + (e - s) * frac) - sceneStart(i);
};
