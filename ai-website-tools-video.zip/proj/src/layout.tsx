import React from "react";

/** Absolute-position an element by its CENTER point. */
export const Pos: React.FC<{ x: number; y: number; style?: React.CSSProperties; children: React.ReactNode }> = ({ x, y, style, children }) => (
  <div style={{ position: "absolute", left: x, top: y, transform: "translate(-50%, -50%)", width: "max-content", ...style }}>{children}</div>
);
