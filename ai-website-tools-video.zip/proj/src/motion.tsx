import React, { createContext, useContext } from "react";
import { Audio, Sequence, interpolate, spring, staticFile, useCurrentFrame, useVideoConfig } from "remotion";
import { theme } from "./theme";
import { SFX } from "./config";
import { localAt, sceneDur } from "./timeline";

export const CL = { extrapolateLeft: "clamp", extrapolateRight: "clamp" } as const;

/** clamped, eased tween on the current local frame */
export const useTween = () => {
  const frame = useCurrentFrame();
  return (a: number, b: number, from: number, to: number, easing: (t: number) => number = theme.ease.out) =>
    interpolate(frame, [a, b], [from, to], { easing, ...CL });
};

export const useSpr = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  return (delay: number, config: { damping: number; stiffness: number; mass: number } = theme.spring.snappy) =>
    spring({ frame: frame - delay, fps, config });
};

/** Scene time context: `at(cue, frac)` gives local frames derived from the SRT. */
const Ctx = createContext<{ i: number; dur: number; at: (cue: number, frac?: number) => number }>({
  i: 0, dur: 100, at: () => 0,
});
export const SceneProvider: React.FC<{ index: number; children: React.ReactNode }> = ({ index, children }) => (
  <Ctx.Provider value={{ i: index, dur: sceneDur(index), at: (c, f = 0) => localAt(index, c, f) }}>{children}</Ctx.Provider>
);
export const useScene = () => useContext(Ctx);

/** Breathing micro-motion for idle elements */
export const useIdle = (speed = 1, phase = 0) => {
  const frame = useCurrentFrame();
  const t = frame * speed + phase;
  return { y: Math.sin(t / 30) * 6, s: 1 + Math.sin(t / 22) * 0.012, r: Math.sin(t / 45) * 0.8 };
};

/* ---------------------------------------------------------------- SFX */
const SFX_DUR = { pop: 0.24, click: 0.11, whoosh: 0.7, swipe: 0.5, chime: 0.5, thud: 0.38 } as const;
const SFX_VOL = { pop: 0.3, click: 0.26, whoosh: 0.26, swipe: 0.28, chime: 0.3, thud: 0.34 } as const;
export type SfxName = keyof typeof SFX_DUR;

/** `at` is a frame in the current Sequence. Fires 2–3 frames BEFORE the visual lands. */
export const Sfx: React.FC<{ name: SfxName; at: number; rate?: number; gain?: number }> = ({ name, at, rate = 1, gain = 1 }) => {
  const { fps } = useVideoConfig();
  if (!SFX.enabled) return null;
  return (
    <Sequence from={Math.max(0, Math.round(at))} durationInFrames={Math.ceil((SFX_DUR[name] / rate) * fps) + 2} layout="none">
      <Audio src={staticFile(`sfx/${name}.wav`)} volume={SFX_VOL[name] * gain * SFX.master} playbackRate={rate} />
    </Sequence>
  );
};
