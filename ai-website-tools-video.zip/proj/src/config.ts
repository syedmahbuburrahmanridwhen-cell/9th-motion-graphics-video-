// Preview voiceover: drop your MP3 at public/voiceover.mp3 to hear it in Remotion Studio.
export const VOICEOVER = {
  /** master switch for the PreviewAudio component */
  enabled: true,
  /** keep false so exported MP4 contains SFX only (set true to bake the voiceover into the render) */
  includeInRender: false,
  file: "voiceover.mp3",
  volume: 1,
};
/** SFX master switch + overall level multiplier */
export const SFX = { enabled: true, master: 1 };
