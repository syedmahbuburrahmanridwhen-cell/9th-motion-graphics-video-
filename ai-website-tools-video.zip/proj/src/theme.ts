// theme.ts — single source of truth: colors, easings, springs, fonts. Palette = "Deep Space Blue".
import { Easing } from "remotion";

const primary = "#3B82F6";
const accent = "#22D3EE";

export const theme = {
  colors: {
    bg: "#070B1A",
    bgAlt: "#0D1430",
    bgDeep: "#03050E",
    primary, // hero
    accent,
    text: "#F1F5F9",
    textDim: "#94A3B8",
    white: "#FFFFFF",
    ink: "#0B1020",
    glow: "rgba(59,130,246,0.45)",
    glowSoft: "rgba(59,130,246,0.18)",
    glowAccent: "rgba(34,211,238,0.30)",
    surface: "rgba(255,255,255,0.06)",
    surfaceStrong: "rgba(255,255,255,0.11)",
    border: "rgba(255,255,255,0.14)",
    borderSoft: "rgba(255,255,255,0.08)",
    shadow: "rgba(0,0,0,0.55)",
    // tints used by illustrative UI mockups (derived from the palette)
    tints: ["#3B82F6", "#22D3EE", "#93C5FD", "#1E40AF", "#67E8F9", "#2563EB"],
  },
  gradient: {
    hero: `linear-gradient(120deg, ${primary} 0%, ${accent} 100%)`,
    heroV: `linear-gradient(180deg, ${primary} 0%, ${accent} 100%)`,
    card: "linear-gradient(150deg, rgba(255,255,255,0.12) 0%, rgba(255,255,255,0.04) 100%)",
  },
  fonts: { display: "'Hind Siliguri', sans-serif" },
  radius: { sm: 14, md: 24, lg: 36 },
  ease: {
    out: Easing.bezier(0.16, 1, 0.3, 1),
    inOut: Easing.bezier(0.83, 0, 0.17, 1),
    wipe: Easing.bezier(0.65, 0, 0.35, 1),
    in: Easing.bezier(0.7, 0, 0.84, 0),
  },
  spring: {
    snappy: { damping: 14, stiffness: 160, mass: 0.6 },
    smooth: { damping: 20, stiffness: 90, mass: 1 },
    bouncy: { damping: 11, stiffness: 170, mass: 0.7 },
    soft: { damping: 26, stiffness: 70, mass: 1 },
  },
  size: { hero: 176, title: 112, h2: 84, body: 54, small: 38 },
} as const;
