import React from "react";
import { AbsoluteFill, interpolate, useCurrentFrame } from "remotion";
import { theme } from "../theme";
import { CL, Sfx, useIdle, useScene, useSpr, useTween } from "../motion";
import { Enter, Glass, GradText, Icon, Words } from "../components";
import { Pos } from "../layout";

const CHIPS = [
  { t: "<div>", x: 190, y: 170 }, { t: "{ }", x: 1560, y: 150 }, { t: "npm i", x: 250, y: 860 },
  { t: "css", x: 1560, y: 880 }, { t: "<h1>", x: 1760, y: 520 }, { t: "fn()", x: 150, y: 520 }, { t: "</>", x: 900, y: 940 },
];

export const Hook: React.FC = () => {
  const { at } = useScene();
  const frame = useCurrentFrame();
  const spr = useSpr();
  const tw = useTween();
  const idle = useIdle();

  const a1 = at(1, 0);
  const l2 = at(1, 0.42);
  const t2 = at(2, 0) - 2;
  const strike = at(2, 0.2);
  const wrong = at(2, 0.44);
  const exit1 = at(2, 0) - 12;

  const out = tw(strike + 6, strike + 24, 0, 1, theme.ease.in);
  const shake = Math.sin(frame * 1.9) * 9 * Math.max(0, 1 - (frame - t2) / 26) * (frame > t2 ? 1 : 0);
  const impossibleP = spr(t2, theme.spring.bouncy);
  const strikeW = tw(strike, strike + 10, 0, 100);
  const impossibleFade = tw(wrong - 6, wrong + 4, 1, 0, theme.ease.in);

  // wireframe website draws behind "একদম ভুল।"
  const draw = tw(wrong, wrong + 40, 0, 1, theme.ease.inOut);
  const checkP = spr(wrong + 26, theme.spring.bouncy);

  return (
    <AbsoluteFill>
      {/* big </> glyph, draws in then shatters */}
      <Pos x={1500} y={560} style={{ opacity: 0.22 * (1 - out) * tw(a1, a1 + 14, 0, 1), transform: `translate(-50%,-50%) translateY(${idle.y * 2}px) rotate(${idle.r * 3}deg) scale(${1 + out * 0.6})` }}>
        <Icon name="code" size={640} color={theme.colors.accent} stroke={0.5} draw={tw(a1, a1 + 36, 0, 1, theme.ease.inOut)} />
      </Pos>
      {CHIPS.map((c, i) => {
        const p = spr(a1 + i * 4, theme.spring.snappy);
        const dx = (c.x - 960) * out * 1.4, dy = (c.y - 540) * out * 1.4;
        return (
          <Pos key={i} x={c.x} y={c.y} style={{ opacity: Math.min(1, p * 1.5) * (1 - out) * 0.85, transform: `translate(-50%,-50%) translate(${dx}px, ${dy + Math.sin(frame / 24 + i) * 8}px) rotate(${out * 40 + (i % 2 ? 4 : -4)}deg) scale(${0.6 + 0.4 * p})` }}>
            <Glass radius={22} pad={0} style={{ padding: "12px 30px" }}>
              <span style={{ fontFamily: theme.fonts.display, fontWeight: 600, fontSize: 40, color: theme.colors.accent }}>{c.t}</span>
            </Glass>
          </Pos>
        );
      })}

      {/* phase 1: the question */}
      <Pos x={960} y={400}><Words text="Coding না জেনে" delay={a1} per={6} size={178} exitAt={exit1} /></Pos>
      <Pos x={960} y={640}><Words text="website বানানো কি" delay={l2} per={7} size={178} hi={[0]} exitAt={exit1} /></Pos>

      {/* phase 2: "অসম্ভব?" struck through */}
      <Pos x={960 + shake} y={500} style={{ opacity: Math.min(1, impossibleP * 1.5) * impossibleFade, transform: `translate(-50%,-50%) scale(${0.5 + 0.5 * impossibleP})` }}>
        <div style={{ position: "relative", fontFamily: theme.fonts.display, fontWeight: 700, fontSize: 280, lineHeight: 1.3, color: theme.colors.text }}>
          অসম্ভব?
          <div style={{ position: "absolute", left: -20, top: "56%", height: 18, width: `${strikeW}%`, background: theme.colors.primary, borderRadius: 9, transform: "rotate(-3deg)", boxShadow: `0 0 40px ${theme.colors.glow}` }} />
        </div>
      </Pos>

      {/* phase 3: "একদম ভুল।" over a wireframe website */}
      <Pos x={960} y={560} style={{ opacity: 0.55 * tw(wrong, wrong + 10, 0, 1) }}>
        <svg width="1180" height="680" viewBox="0 0 1180 680" fill="none" stroke={theme.colors.accent} strokeWidth="3" strokeLinecap="round" strokeLinejoin="round">
          {[
            "M20 20H1160V660H20Z", "M20 90H1160", "M60 55H120", "M900 55H1120", "M60 150H620V330H60Z", "M700 150H1120V330H700Z",
            "M60 380H400V620H60Z", "M420 380H760V620H420Z", "M780 380H1120V620H780Z",
          ].map((d, i) => <path key={i} d={d} pathLength={1} strokeDasharray={1} strokeDashoffset={1 - Math.min(1, Math.max(0, draw * 1.6 - i * 0.07))} />)}
        </svg>
      </Pos>
      <Pos x={960} y={540} style={{ filter: `drop-shadow(0 0 50px ${theme.colors.glow})` }}>
        <Words text="একদম ভুল।" delay={wrong} per={7} size={250} hi={[1]} />
      </Pos>
      <Pos x={960} y={790} style={{ transform: `translate(-50%,-50%) scale(${0.3 + 0.7 * checkP})`, opacity: Math.min(1, checkP * 1.5) }}>
        <div style={{ width: 120, height: 120, borderRadius: 60, background: theme.gradient.hero, display: "flex", alignItems: "center", justifyContent: "center", boxShadow: `0 0 60px ${theme.colors.glow}` }}>
          <Icon name="check" size={70} color={theme.colors.white} stroke={2.8} draw={tw(wrong + 30, wrong + 46, 0, 1)} />
        </div>
      </Pos>

      <Sfx name="thud" at={a1 - 2} />
      <Sfx name="pop" at={t2 - 3} rate={0.95} />
      <Sfx name="click" at={strike - 2} />
      <Sfx name="thud" at={wrong - 3} gain={0.8} rate={1.1} />
      <Sfx name="chime" at={wrong + 26} gain={0.7} rate={1.1} />
    </AbsoluteFill>
  );
};
void interpolate; void CL; void Enter; void GradText;
