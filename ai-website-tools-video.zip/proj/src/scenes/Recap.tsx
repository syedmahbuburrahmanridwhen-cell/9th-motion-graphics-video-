import React from "react";
import { AbsoluteFill, Img, staticFile, useCurrentFrame } from "remotion";
import { theme } from "../theme";
import { Sfx, useIdle, useScene, useSpr, useTween } from "../motion";
import { Cursor, Enter, Glass, GradText, Icon, LogoMark, Pill, Ripple, TypeChars, Words } from "../components";
import { Pos } from "../layout";

const Avatar: React.FC<{ size: number; ring?: boolean }> = ({ size, ring = true }) => (
  <div style={{ width: size, height: size, borderRadius: "50%", padding: ring ? 5 : 0, background: ring ? theme.gradient.hero : "none", boxSizing: "border-box", flexShrink: 0 }}>
    <Img src={staticFile("profile.jpg")} style={{ width: "100%", height: "100%", borderRadius: "50%", objectFit: "cover", display: "block", border: ring ? `4px solid ${theme.colors.bg}` : "none", boxSizing: "border-box" }} />
  </div>
);

const TOOLS: { kind: "framer" | "dora" | "hostinger"; name: string }[] = [
  { kind: "framer", name: "Framer" }, { kind: "dora", name: "Dora" }, { kind: "hostinger", name: "Hostinger" },
];

export const Recap: React.FC = () => {
  const { at } = useScene();
  const frame = useCurrentFrame();
  const spr = useSpr();
  const tw = useTween();
  const idle = useIdle();

  const a19 = at(19, 0), a20 = at(20, 0), a21 = at(21, 0);
  const move = tw(a20 - 2, a20 + 22, 0, 1, theme.ease.inOut);
  const rowY = 540 - 365 * move;
  const rowS = 1 - 0.5 * move;
  const followAt = at(20, 0.5);
  const followP = spr(followAt, theme.spring.bouncy);
  const press1 = tw(followAt - 3, followAt + 2, 0, 1) * (1 - tw(followAt + 2, followAt + 9, 0, 1));
  const typeAt = at(21, 0.12);
  const sendAt = at(21, 0.5);
  const press2 = tw(sendAt - 3, sendAt + 2, 0, 1) * (1 - tw(sendAt + 2, sendAt + 9, 0, 1));
  const inboxAt = at(20, 0.55);
  const rowsAt = at(21, 0.62);
  const cur = tw(followAt - 18, followAt - 3, 0, 1, theme.ease.inOut);
  const cur2 = tw(sendAt - 16, sendAt - 3, 0, 1, theme.ease.inOut);
  const ui = spr(a20 + 12, theme.spring.smooth);

  return (
    <AbsoluteFill>
      {/* heading (recap moment) */}
      <Pos x={960} y={120}><Words text="এই tool-গুলোর direct link" delay={a19} per={5} size={88} hi={[2, 3]} exitAt={a20 - 4} /></Pos>

      {/* recap grid of the three tools */}
      <Pos x={960} y={rowY} style={{ transform: `translate(-50%,-50%) scale(${rowS})` }}>
        <div style={{ position: "relative", width: 1620, height: 360 }}>
          {TOOLS.map((t, i) => {
            const p = spr(a19 + 8 + i * 6, theme.spring.bouncy);
            const x = 810 + (i - 1) * 600;
            return (
              <div key={t.kind} style={{ position: "absolute", left: x - 260, top: 10, width: 520, height: 340, opacity: Math.min(1, p * 1.5), transform: `scale(${0.4 + 0.6 * p}) translateY(${(1 - p) * 60 + Math.sin(frame / 26 + i * 2) * 5}px)` }}>
                <Glass w={520} h={340} radius={38} style={{ display: "flex", alignItems: "center", justifyContent: "center" }}>
                  <div style={{ position: "absolute", left: 28, top: 14 }}><GradText style={{ fontFamily: theme.fonts.display, fontWeight: 700, fontSize: 64, lineHeight: 1.2 }}>{`0${i + 1}`}</GradText></div>
                  <div style={{ position: "absolute", right: 28, top: 28 }}><Icon name="link" size={56} color={theme.colors.accent} /></div>
                  <div style={{ marginTop: 20 }}><LogoMark kind={t.kind} size={t.kind === "hostinger" ? 330 : 250} delay={a19 + 12 + i * 6} float={false} /></div>
                </Glass>
              </div>
            );
          })}
        </div>
      </Pos>

      {/* comment card */}
      <Pos x={570} y={725} style={{ opacity: Math.min(1, ui * 1.4), transform: `translate(-50%,-50%) translateY(${(1 - ui) * 80}px) scale(${0.9 + 0.1 * ui})` }}>
        <Glass w={900} h={440} radius={38} pad={34}>
          <div style={{ display: "flex", alignItems: "center", gap: 26 }}>
            <Avatar size={118} />
            <div style={{ flex: 1, display: "flex", flexDirection: "column", gap: 12 }}>
              <div style={{ height: 18, width: 250, borderRadius: 9, background: theme.colors.text, opacity: 0.85 }} />
              <div style={{ height: 13, width: 170, borderRadius: 7, background: theme.colors.surfaceStrong }} />
            </div>
            <div style={{ position: "relative", width: 250, height: 90 }}>
              <div style={{ position: "absolute", inset: 0, display: "flex", alignItems: "center", justifyContent: "center", gap: 12, borderRadius: 45, background: theme.gradient.hero, color: theme.colors.white, fontFamily: theme.fonts.display, fontWeight: 700, fontSize: 42, boxShadow: `0 10px 34px ${theme.colors.glow}`, opacity: 1 - Math.min(1, followP * 2), transform: `scale(${1 - press1 * 0.12})` }}>
                <Icon name="userplus" size={40} color={theme.colors.white} stroke={2.2} />Follow
              </div>
              <div style={{ position: "absolute", inset: 0, display: "flex", alignItems: "center", justifyContent: "center", gap: 12, borderRadius: 45, background: theme.colors.surfaceStrong, border: `2px solid ${theme.colors.accent}`, color: theme.colors.text, fontFamily: theme.fonts.display, fontWeight: 700, fontSize: 36, opacity: Math.min(1, followP * 1.6), transform: `scale(${0.7 + 0.3 * followP})` }}>
                <Icon name="check" size={38} color={theme.colors.accent} stroke={2.8} />Following
              </div>
            </div>
          </div>
          <div style={{ marginTop: 34, fontFamily: theme.fonts.display, fontWeight: 500, fontSize: 32, color: theme.colors.textDim, lineHeight: 1.3 }}>comment</div>
          <div style={{ marginTop: 6, height: 128, borderRadius: 30, background: theme.colors.surface, border: `2px solid ${frame >= typeAt - 4 ? theme.colors.accent : theme.colors.border}`, display: "flex", alignItems: "center", padding: "0 30px", gap: 24, boxShadow: frame >= typeAt - 4 ? `0 0 40px ${theme.colors.glowAccent}` : "none" }}>
            <Avatar size={64} ring={false} />
            <div style={{ flex: 1 }}><TypeChars text="AI" start={typeAt} per={9} size={72} /></div>
            <div style={{ width: 84, height: 84, borderRadius: 42, background: theme.gradient.hero, display: "flex", alignItems: "center", justifyContent: "center", transform: `scale(${1 - press2 * 0.16})`, boxShadow: `0 8px 28px ${theme.colors.glow}` }}><Icon name="plane" size={44} color={theme.colors.white} stroke={2.2} /></div>
          </div>
        </Glass>
      </Pos>
      <Ripple at={followAt} x={570 + 450 - 34 - 125} y={725 - 220 + 34 + 59} size={200} />
      <Ripple at={sendAt} x={570 + 450 - 34 - 30 - 42} y={725 + 220 - 34 - 64} size={170} />
      <Cursor x={570 + 450 - 34 - 125 + 40 + (1 - cur) * 120} y={725 - 220 + 34 + 59 + 20 + (1 - cur) * 120} press={press1} opacity={cur * (1 - tw(followAt + 12, followAt + 20, 0, 1))} />
      <Cursor x={570 + 450 - 34 - 30 - 42 + 30 + (1 - cur2) * 100} y={725 + 220 - 34 - 64 + 20 + (1 - cur2) * 100} press={press2} opacity={cur2 * (1 - tw(sendAt + 12, sendAt + 20, 0, 1))} />

      {/* inbox card */}
      <Pos x={1410} y={725 + idle.y * 0.5} style={{ opacity: tw(inboxAt, inboxAt + 10, 0, 1), transform: `translate(-50%,-50%) scale(${0.6 + 0.4 * spr(inboxAt, theme.spring.bouncy)})` }}>
        <Glass w={640} h={440} radius={38} pad={32} style={{ borderColor: frame >= rowsAt ? theme.colors.accent : theme.colors.border }}>
          <div style={{ display: "flex", alignItems: "center", gap: 18, marginBottom: 20 }}>
            <Icon name="mail" size={56} color={theme.colors.accent} />
            <span style={{ fontFamily: theme.fonts.display, fontWeight: 700, fontSize: 52, color: theme.colors.text, lineHeight: 1.3 }}>inbox</span>
          </div>
          <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
            {TOOLS.map((t, i) => (
              <Enter key={t.kind} delay={rowsAt + i * 6} dir="left" dist={90}>
                <div style={{ display: "flex", alignItems: "center", gap: 18, height: 88, borderRadius: 24, background: theme.colors.surfaceStrong, border: `1.5px solid ${theme.colors.border}`, padding: "0 26px" }}>
                  <Icon name="link" size={44} color={theme.colors.accent} />
                  <span style={{ fontFamily: theme.fonts.display, fontWeight: 600, fontSize: 40, color: theme.colors.text, lineHeight: 1.3 }}>{t.name}</span>
                  <div style={{ flex: 1 }} />
                  <div style={{ width: 90, height: 12, borderRadius: 6, background: theme.colors.surface }} />
                </div>
              </Enter>
            ))}
          </div>
        </Glass>
      </Pos>

      <Sfx name="pop" at={a19 + 6} rate={0.92} />
      <Sfx name="pop" at={a19 + 12} rate={1.0} />
      <Sfx name="pop" at={a19 + 18} rate={1.08} />
      <Sfx name="whoosh" at={a20 - 3} gain={0.7} />
      <Sfx name="click" at={followAt - 2} />
      <Sfx name="click" at={sendAt - 2} gain={0.9} rate={1.05} />
      <Sfx name="pop" at={rowsAt - 2} rate={0.95} />
      <Sfx name="chime" at={rowsAt + 10} gain={0.8} />
    </AbsoluteFill>
  );
};
void Pill;
