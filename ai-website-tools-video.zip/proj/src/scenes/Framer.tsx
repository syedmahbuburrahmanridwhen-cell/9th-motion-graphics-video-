import React from "react";
import { AbsoluteFill, useCurrentFrame } from "remotion";
import { theme } from "../theme";
import { Sfx, useIdle, useScene, useSpr, useTween } from "../motion";
import { BrowserWindow, Enter, Glass, GradText, Icon, LogoMark, NumberBadge, Pill, Ripple, SweepType, Words } from "../components";
import { Pos } from "../layout";

const WIN = { x: 780, y: 110, w: 1040, h: 780 };
const BOOKS = [
  { h: 210, w: 46, c: 0 }, { h: 168, w: 40, c: 1 }, { h: 236, w: 54, c: 3 }, { h: 190, w: 44, c: 2 }, { h: 150, w: 38, c: 4 }, { h: 224, w: 48, c: 5 },
];

/** grows from the left like a drawn text bar */
const Bar: React.FC<{ w: number; h: number; delay: number; color?: string; hl?: number; style?: React.CSSProperties }> = ({ w, h, delay, color = theme.colors.surfaceStrong, hl = 0, style }) => {
  const spr = useSpr();
  const p = spr(delay, theme.spring.smooth);
  return <div style={{ width: w, height: h, borderRadius: h / 2, background: color, transformOrigin: "0 50%", transform: `scaleX(${p})`, opacity: Math.min(1, p * 2), boxShadow: hl > 0 ? `0 0 0 ${4 * hl}px ${theme.colors.accent}, 0 0 ${30 * hl}px ${theme.colors.accent}` : "none", ...style }} />;
};

export const Framer: React.FC = () => {
  const { at, dur } = useScene();
  const frame = useCurrentFrame();
  const spr = useSpr();
  const tw = useTween();
  const idle = useIdle();

  const a5 = at(5, 0), a6 = at(6, 0), a7 = at(7, 0);
  const submit = a7 + 20;
  const build = a7 + 26;
  const chipT = [at(8, 0.12), at(8, 0.42), at(8, 0.7)];
  const money = at(9, 0.42);
  const chipsOut = money - 8;

  // "ready" check pop at the very start (continues the 20-second ring from the previous scene)
  const readyP = spr(a5 - 2, theme.spring.bouncy);
  const readyOut = tw(a5 + 16, a5 + 28, 0, 1, theme.ease.in);

  const pulse = (t: number) => { const p = tw(t, t + 30, 0, 1, theme.ease.inOut); return Math.sin(p * Math.PI); };
  const hlDesign = pulse(chipT[0]), hlImage = pulse(chipT[1]), hlText = pulse(chipT[2]);
  const typing = frame >= a6 + 4 && frame < submit;
  const sendPress = tw(submit - 3, submit + 3, 0, 1) * (1 - tw(submit + 3, submit + 10, 0, 1));

  const dim = tw(money - 6, money + 10, 0, 1);
  const sheen = tw(money + 4, money + 34, -500, 1500, theme.ease.inOut);
  const burst = tw(money, money + 26, 0, 1);

  return (
    <AbsoluteFill>
      {/* ready check */}
      <Pos x={960} y={520} style={{ opacity: (1 - readyOut) * Math.min(1, readyP * 1.5), transform: `translate(-50%,-50%) scale(${(0.3 + 0.7 * readyP) * (1 + readyOut * 0.7)})` }}>
        <div style={{ width: 280, height: 280, borderRadius: "50%", background: theme.gradient.hero, display: "flex", alignItems: "center", justifyContent: "center", boxShadow: `0 0 110px ${theme.colors.glow}`, margin: "0 auto" }}>
          <Icon name="check" size={170} color={theme.colors.white} stroke={2.6} draw={tw(a5, a5 + 12, 0, 1)} />
        </div>
        <div style={{ textAlign: "center", fontFamily: theme.fonts.display, fontWeight: 700, fontSize: 84, color: theme.colors.text, marginTop: 24 }}>ready</div>
      </Pos>

      {/* left column: number, logo, title */}
      <Pos x={410} y={170}><NumberBadge n="01" delay={a5 + 20} /></Pos>
      <Pos x={410} y={470}><LogoMark kind="framer" size={430} delay={a5 + 28} /></Pos>
      <Pos x={410} y={790}><Words text="Framer AI" delay={a5 + 38} per={6} size={108} hi={[1]} /></Pos>

      {/* browser window */}
      <div style={{ position: "absolute", left: WIN.x, top: WIN.y, filter: dim > 0.001 ? `brightness(${1 - dim * 0.68}) blur(${dim * 5}px)` : undefined, transform: `scale(${1 - dim * 0.05})` }}>
        <Enter delay={a5 + 30} dir="right" dist={240}>
          <div style={{ transform: `translateY(${idle.y}px)` }}>
            <BrowserWindow w={WIN.w} h={WIN.h} url="framer.com">
              {/* prompt bar */}
              <div style={{ position: "absolute", left: 36, top: 28, width: WIN.w - 72, height: 122 }}>
                <Glass w="100%" h="100%" radius={30} style={{ display: "flex", alignItems: "center", gap: 26, padding: "0 30px", borderColor: typing ? theme.colors.accent : theme.colors.border, boxShadow: typing ? `0 0 50px ${theme.colors.glowAccent}` : undefined }}>
                  <Icon name="spark" size={54} color={theme.colors.accent} />
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ fontFamily: theme.fonts.display, fontWeight: 500, fontSize: 24, color: theme.colors.textDim, lineHeight: 1.2, marginBottom: 2 }}>Prompt</div>
                    <SweepType text="একটা বইয়ের দোকানের website বানাও" start={a6 + 4} end={a7 + 14} size={46} caret={frame < submit + 4} />
                  </div>
                  <div style={{ width: 82, height: 82, borderRadius: 41, background: theme.gradient.hero, display: "flex", alignItems: "center", justifyContent: "center", transform: `scale(${1 - sendPress * 0.18})`, boxShadow: `0 10px 34px ${theme.colors.glow}` }}>
                    <Icon name="arrow" size={42} color={theme.colors.white} stroke={2.6} />
                  </div>
                </Glass>
              </div>
              <Ripple at={submit} x={WIN.w - 36 - 30 - 41} y={28 + 61} size={190} />

              {/* generated website canvas */}
              <div style={{ position: "absolute", left: 36, top: 176, width: WIN.w - 72, height: 520, borderRadius: 26, background: "rgba(255,255,255,0.035)", border: `1.5px solid ${theme.colors.borderSoft}`, overflow: "hidden", boxShadow: hlDesign > 0 ? `0 0 0 ${5 * hlDesign}px ${theme.colors.accent}, 0 0 ${50 * hlDesign}px ${theme.colors.glowAccent}` : "none" }}>
                {/* build progress */}
                <div style={{ position: "absolute", left: 0, top: 0, height: 6, width: `${tw(build - 6, build + 52, 0, 100, theme.ease.inOut)}%`, background: theme.gradient.hero, opacity: tw(build + 50, build + 62, 1, 0) }} />
                {/* nav */}
                <div style={{ position: "absolute", left: 28, right: 28, top: 22, display: "flex", alignItems: "center", gap: 26 }}>
                  <Enter delay={build} dir="down" dist={24} style={{ display: "flex", alignItems: "center", gap: 12 }}>
                    <Icon name="hex" size={34} color={theme.colors.accent} stroke={2.2} />
                    <span style={{ fontFamily: theme.fonts.display, fontWeight: 700, fontSize: 30, color: theme.colors.text }}>বইয়ের দোকান</span>
                  </Enter>
                  <div style={{ flex: 1, display: "flex", justifyContent: "center", gap: 26 }}>
                    {[0, 1, 2].map((i) => <Bar key={i} w={76} h={10} delay={build + 6 + i * 3} />)}
                  </div>
                  <Enter delay={build + 10} dir="down" dist={24}><div style={{ width: 112, height: 38, borderRadius: 19, background: theme.gradient.hero }} /></Enter>
                </div>
                {/* hero text */}
                <div style={{ position: "absolute", left: 30, top: 100, display: "flex", flexDirection: "column", gap: 16 }}>
                  <Bar w={420} h={34} delay={build + 14} color={theme.colors.text} hl={hlText} />
                  <Bar w={300} h={34} delay={build + 18} color={theme.colors.text} hl={hlText} />
                  <div style={{ height: 6 }} />
                  <Bar w={440} h={13} delay={build + 24} hl={hlText} />
                  <Bar w={370} h={13} delay={build + 27} hl={hlText} />
                  <Bar w={400} h={13} delay={build + 30} hl={hlText} />
                  <Enter delay={build + 36} dir="up" dist={20} style={{ marginTop: 10 }}><div style={{ width: 176, height: 52, borderRadius: 26, background: theme.gradient.hero, boxShadow: `0 10px 30px ${theme.colors.glow}` }} /></Enter>
                </div>
                {/* book illustration */}
                <div style={{ position: "absolute", right: 46, top: 84, width: 400, height: 250, display: "flex", alignItems: "flex-end", justifyContent: "center", gap: 10, borderRadius: 22, boxShadow: hlImage > 0 ? `0 0 0 ${4 * hlImage}px ${theme.colors.accent}, 0 0 ${40 * hlImage}px ${theme.colors.glowAccent}` : "none" }}>
                  {BOOKS.map((b, i) => {
                    const p = spr(build + 22 + i * 4, theme.spring.bouncy);
                    return (
                      <div key={i} style={{ width: b.w, height: b.h * p, borderRadius: 8, background: `linear-gradient(180deg, ${theme.colors.tints[b.c]}, ${theme.colors.tints[(b.c + 3) % 6]})`, position: "relative", opacity: Math.min(1, p * 2), boxShadow: "0 12px 24px -8px rgba(0,0,0,0.6)" }}>
                        <div style={{ position: "absolute", left: 6, right: 6, top: 22, height: 5, borderRadius: 3, background: "rgba(255,255,255,0.7)" }} />
                        <div style={{ position: "absolute", left: 6, right: 6, top: 36, height: 5, borderRadius: 3, background: "rgba(255,255,255,0.35)" }} />
                      </div>
                    );
                  })}
                  <div style={{ position: "absolute", left: 0, right: 0, bottom: -10, height: 8, borderRadius: 4, background: theme.colors.border }} />
                </div>
                {/* product cards */}
                <div style={{ position: "absolute", left: 28, right: 28, top: 346, display: "flex", gap: 22 }}>
                  {[0, 1, 2].map((i) => {
                    const p = spr(build + 44 + i * 6, theme.spring.smooth);
                    return (
                      <div key={i} style={{ flex: 1, height: 148, borderRadius: 20, background: theme.colors.surface, border: `1.5px solid ${theme.colors.borderSoft}`, opacity: Math.min(1, p * 1.6), transform: `translateY(${(1 - p) * 60}px)`, padding: 14, boxSizing: "border-box" }}>
                        <div style={{ height: 84, borderRadius: 12, background: `linear-gradient(135deg, ${theme.colors.tints[(i * 2) % 6]}, ${theme.colors.tints[(i * 2 + 4) % 6]})`, boxShadow: hlImage > 0 ? `0 0 0 ${3 * hlImage}px ${theme.colors.accent}` : "none" }} />
                        <div style={{ display: "flex", flexDirection: "column", gap: 8, marginTop: 12 }}>
                          <div style={{ width: "70%", height: 10, borderRadius: 5, background: theme.colors.text, opacity: 0.8, boxShadow: hlText > 0 ? `0 0 0 ${3 * hlText}px ${theme.colors.accent}` : "none" }} />
                          <div style={{ width: "45%", height: 9, borderRadius: 5, background: theme.colors.surfaceStrong }} />
                        </div>
                      </div>
                    );
                  })}
                </div>
                {/* sheen */}
                <div style={{ position: "absolute", top: -50, bottom: -50, left: sheen, width: 180, transform: "skewX(-18deg)", background: "linear-gradient(90deg, transparent, rgba(255,255,255,0.35), transparent)" }} />
              </div>
            </BrowserWindow>
          </div>
        </Enter>
      </div>

      {/* chips: design · ছবি · লেখা */}
      <Pos x={WIN.x + WIN.w / 2} y={965}>
        <div style={{ display: "flex", gap: 28 }}>
          {([["layout", "design"], ["image", "ছবি"], ["type", "লেখা"]] as const).map(([ic, label], i) => (
            <Enter key={label} delay={chipT[i]} dir="up" dist={40} exitAt={chipsOut} cfg={theme.spring.bouncy}>
              <Pill hero={i === 0 ? hlDesign > 0.05 : i === 1 ? hlImage > 0.05 : hlText > 0.05}><Icon name={ic} size={38} color={theme.colors.white} />{label}</Pill>
            </Enter>
          ))}
        </div>
      </Pos>

      {/* payoff: কোটি টাকার মতো */}
      <Pos x={WIN.x + WIN.w / 2} y={WIN.y + WIN.h / 2 - 20}>
        <div style={{ position: "absolute", left: -120, right: -120, top: -90, bottom: -90, borderRadius: "50%", background: `radial-gradient(ellipse, rgba(3,5,14,0.88) 0%, rgba(3,5,14,0.6) 55%, transparent 75%)`, opacity: dim }} />
        <div style={{ position: "relative", filter: `drop-shadow(0 0 40px ${theme.colors.glow})` }}>
          <Words text="দেখতে কোটি টাকার" delay={money} per={5} size={104} hi={[1, 2]} />
          <Words text="মতো লাগবে" delay={money + 14} per={5} size={104} style={{ marginTop: 6 }} />
        </div>
      </Pos>
      {Array.from({ length: 10 }).map((_, i) => {
        const th = (i / 10) * Math.PI * 2 + 0.3, r = 360 + (i % 3) * 70;
        const p = burst;
        return (
          <Pos key={i} x={WIN.x + WIN.w / 2 + Math.cos(th) * r * p} y={WIN.y + WIN.h / 2 + Math.sin(th) * r * 0.62 * p} style={{ opacity: p > 0 ? (1 - p * 0.35) * Math.min(1, burst * 4) * (0.6 + 0.4 * Math.sin(frame / 5 + i)) : 0, transform: `translate(-50%,-50%) scale(${0.5 + (i % 3) * 0.35}) rotate(${p * 90}deg)` }}>
            <Icon name="spark" size={54} color={i % 2 ? theme.colors.accent : theme.colors.text} stroke={1.8} />
          </Pos>
        );
      })}

      <Sfx name="chime" at={a5 + 25} />
      <Sfx name="pop" at={a5 + 17} gain={0.8} rate={0.95} />
      <Sfx name="pop" at={a5 + 27} gain={0.9} rate={1.05} />
      <Sfx name="click" at={submit - 2} />
      <Sfx name="pop" at={build - 2} rate={0.9} />
      <Sfx name="pop" at={chipT[0] - 2} rate={1.0} />
      <Sfx name="pop" at={chipT[1] - 2} rate={1.08} />
      <Sfx name="pop" at={chipT[2] - 2} rate={1.16} />
      <Sfx name="chime" at={money - 3} rate={1.12} gain={0.9} />
      <Sfx name="whoosh" at={money - 6} gain={0.7} rate={1.05} />
    </AbsoluteFill>
  );
};

