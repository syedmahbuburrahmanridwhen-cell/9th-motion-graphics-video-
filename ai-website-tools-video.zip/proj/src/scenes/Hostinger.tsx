import React from "react";
import { AbsoluteFill, useCurrentFrame } from "remotion";
import { theme } from "../theme";
import { Sfx, useIdle, useScene, useSpr, useTween } from "../motion";
import { Cursor, Enter, Glass, GradText, Icon, LogoMark, NumberBadge, Ripple, Words } from "../components";
import { Pos } from "../layout";

const NX = [330, 750, 1170, 1590];
const NY = 610;

const NodeCard: React.FC<{ x: number; delay: number; label: string; children: React.ReactNode; hot?: boolean }> = ({ x, delay, label, children, hot }) => {
  const spr = useSpr();
  const idle = useIdle(1, x);
  const p = spr(delay, theme.spring.bouncy);
  return (
    <Pos x={x} y={NY + idle.y * 0.8} style={{ opacity: Math.min(1, p * 1.5), transform: `translate(-50%,-50%) scale(${0.45 + 0.55 * p}) translateY(${(1 - p) * 50}px)` }}>
      <Glass w={360} h={340} radius={34} style={{ display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "space-between", padding: "34px 24px 26px", boxSizing: "border-box", borderColor: hot ? theme.colors.accent : theme.colors.border, boxShadow: hot ? `0 0 60px ${theme.colors.glowAccent}, 0 30px 70px -20px ${theme.colors.shadow}` : undefined }}>
        <div style={{ flex: 1, display: "flex", alignItems: "center", justifyContent: "center", width: "100%" }}>{children}</div>
        <div style={{ fontFamily: theme.fonts.display, fontWeight: 700, fontSize: 40, color: theme.colors.text, lineHeight: 1.3 }}>{label}</div>
      </Glass>
    </Pos>
  );
};

export const Hostinger: React.FC = () => {
  const { at } = useScene();
  const frame = useCurrentFrame();
  const spr = useSpr();
  const tw = useTween();

  const a15 = at(15, 0);
  const n = [at(15, 0.45), at(16, 0.38), at(16, 0.7), at(17, 0.3)];
  const clickAt = at(17, 0.58);
  const dev = at(18, 0.18);
  const strike = at(18, 0.55);

  const lineP = tw(n[0], n[3], 0, 1, theme.ease.inOut);
  const typeW = tw(n[0] + 6, n[0] + 40, 0, 100, theme.ease.inOut);
  const hexDraw = tw(n[1] + 4, n[1] + 34, 0, 1, theme.ease.inOut);
  const siteP = (k: number) => spr(n[2] + 6 + k * 5, theme.spring.smooth);
  const press = tw(clickAt - 3, clickAt + 2, 0, 1) * (1 - tw(clickAt + 2, clickAt + 9, 0, 1));
  const live = spr(clickAt + 4, theme.spring.bouncy);
  const curP = tw(n[3] + 4, clickAt - 2, 0, 1, theme.ease.inOut);
  const strikeP = tw(strike, strike + 12, 0, 1);

  return (
    <AbsoluteFill>
      {/* header: logo left, badge + title right (left-aligned) */}
      <Pos x={330} y={190}><LogoMark kind="hostinger" size={440} delay={a15 + 2} /></Pos>
      <div style={{ position: "absolute", left: 640, top: 84 }}>
        <NumberBadge n="03" delay={a15 - 2} />
        <div style={{ marginTop: 14 }}><Words text="Hostinger AI" delay={a15 + 8} per={6} size={112} hi={[1]} align="left" /></div>
      </div>

      {/* process line */}
      <svg width={1920} height={1080} style={{ position: "absolute", inset: 0 }}>
        {[0, 1, 2].map((i) => {
          const x1 = NX[i] + 182, x2 = NX[i + 1] - 182;
          const seg = Math.min(1, Math.max(0, lineP * 3 - i));
          return (
            <g key={i}>
              <line x1={x1} y1={NY} x2={x2} y2={NY} stroke={theme.colors.borderSoft} strokeWidth={6} strokeLinecap="round" />
              <line x1={x1} y1={NY} x2={x1 + (x2 - x1) * seg} y2={NY} stroke={theme.colors.accent} strokeWidth={6} strokeLinecap="round" />
              <circle cx={x1 + (x2 - x1) * ((frame % 40) / 40) * seg} cy={NY} r={9} fill={theme.colors.white} opacity={seg > 0.05 ? 0.9 : 0} />
            </g>
          );
        })}
      </svg>
      {[540, 960, 1380].map((x, i) => (
        <Pos key={x} x={x} y={NY - 34} style={{ opacity: tw(n[i + 1] - 8, n[i + 1] + 4, 0, 1) }}><Icon name="arrow" size={54} color={theme.colors.accent} stroke={2.6} /></Pos>
      ))}

      {/* 1 business name */}
      <NodeCard x={NX[0]} delay={n[0]} label="business-এর নাম">
        <div style={{ width: 290, height: 92, borderRadius: 22, background: theme.colors.surface, border: `2px solid ${theme.colors.accent}`, display: "flex", alignItems: "center", padding: "0 20px", gap: 14, boxShadow: `0 0 36px ${theme.colors.glowAccent}` }}>
          <Icon name="type" size={38} color={theme.colors.accent} />
          <div style={{ height: 14, width: `${typeW * 0.62}%`, borderRadius: 7, background: theme.colors.text, opacity: 0.85 }} />
          <div style={{ width: 4, height: 38, borderRadius: 2, background: theme.colors.accent, opacity: Math.floor(frame / 12) % 2 === 0 ? 1 : 0.15 }} />
        </div>
      </NodeCard>
      {/* 2 logo */}
      <NodeCard x={NX[1]} delay={n[1]} label="logo">
        <div style={{ position: "relative", width: 170, height: 170, transform: `rotate(${(1 - hexDraw) * -90}deg)` }}>
          <Icon name="hex" size={170} color={theme.colors.accent} stroke={1.3} draw={hexDraw} />
          <div style={{ position: "absolute", inset: 0, display: "flex", alignItems: "center", justifyContent: "center", opacity: hexDraw }}><Icon name="spark" size={74} color={theme.colors.text} stroke={1.8} /></div>
        </div>
      </NodeCard>
      {/* 3 website */}
      <NodeCard x={NX[2]} delay={n[2]} label="website">
        <div style={{ width: 280, height: 190, borderRadius: 18, background: theme.colors.surface, border: `1.5px solid ${theme.colors.border}`, padding: 14, boxSizing: "border-box" }}>
          <div style={{ display: "flex", gap: 6, marginBottom: 12 }}>{[0, 1, 2].map((i) => <div key={i} style={{ width: 9, height: 9, borderRadius: 5, background: theme.colors.surfaceStrong }} />)}</div>
          <div style={{ height: 62, borderRadius: 10, background: theme.gradient.hero, transform: `scaleX(${siteP(0)})`, transformOrigin: "0 50%" }} />
          <div style={{ display: "flex", gap: 8, marginTop: 10 }}>{[1, 2, 3].map((k) => <div key={k} style={{ flex: 1, height: 52, borderRadius: 8, background: theme.colors.surfaceStrong, transform: `scaleY(${siteP(k)})`, transformOrigin: "50% 100%" }} />)}</div>
        </div>
      </NodeCard>
      {/* 4 live in one click */}
      <NodeCard x={NX[3]} delay={n[3]} label="এক click-এ live" hot={live > 0.5}>
        <div style={{ position: "relative", width: 250, height: 130 }}>
          <div style={{ position: "absolute", inset: 0, display: "flex", alignItems: "center", justifyContent: "center", opacity: 1 - Math.min(1, live * 2), transform: `scale(${1 - press * 0.12})` }}>
            <div style={{ width: 130, height: 130, borderRadius: 65, background: theme.gradient.hero, display: "flex", alignItems: "center", justifyContent: "center", boxShadow: `0 0 50px ${theme.colors.glow}` }}><Icon name="bolt" size={66} color={theme.colors.white} stroke={2.2} /></div>
          </div>
          <div style={{ position: "absolute", inset: 0, display: "flex", alignItems: "center", justifyContent: "center", opacity: Math.min(1, live * 1.6), transform: `scale(${0.4 + 0.6 * live})` }}>
            <div style={{ display: "flex", alignItems: "center", gap: 16, padding: "18px 38px", borderRadius: 999, background: theme.colors.surfaceStrong, border: `2px solid ${theme.colors.accent}`, boxShadow: `0 0 40px ${theme.colors.glowAccent}` }}>
              <div style={{ width: 22, height: 22, borderRadius: 11, background: theme.colors.accent, boxShadow: `0 0 0 ${6 + 6 * Math.sin(frame / 5)}px ${theme.colors.glowAccent}` }} />
              <span style={{ fontFamily: theme.fonts.display, fontWeight: 700, fontSize: 56, color: theme.colors.text }}>live</span>
            </div>
          </div>
          <Ripple at={clickAt} x={125} y={65} size={200} />
        </div>
      </NodeCard>
      <Cursor x={NX[3] + 90 - (1 - curP) * 220} y={NY + 20 + (1 - curP) * 150} press={press} opacity={tw(n[3] + 4, n[3] + 12, 0, 1) * (1 - tw(clickAt + 14, clickAt + 24, 0, 1))} />

      {/* developer: before / after */}
      <Pos x={960} y={930}>
        <Enter delay={dev} cfg={theme.spring.bouncy}>
          <Glass radius={999} style={{ display: "flex", alignItems: "center", gap: 26, padding: "8px 60px 8px 42px", opacity: 1 - strikeP * 0.45 }}>
            <Icon name="user" size={70} color={theme.colors.textDim} />
            <div style={{ position: "relative", fontFamily: theme.fonts.display, fontWeight: 700, fontSize: 88, lineHeight: 1.3, color: theme.colors.text }}>
              আলাদা developer
              <div style={{ position: "absolute", left: -14, top: "55%", height: 12, width: `${strikeP * 106}%`, borderRadius: 6, background: theme.colors.primary, boxShadow: `0 0 30px ${theme.colors.glow}`, transform: "rotate(-2deg)" }} />
            </div>
          </Glass>
        </Enter>
      </Pos>

      <Sfx name="chime" at={a15 + 0} />
      <Sfx name="pop" at={n[0] - 2} rate={0.92} />
      <Sfx name="pop" at={n[1] - 2} rate={1.0} />
      <Sfx name="pop" at={n[2] - 2} rate={1.08} />
      <Sfx name="pop" at={n[3] - 2} rate={1.15} />
      <Sfx name="click" at={clickAt - 2} />
      <Sfx name="chime" at={clickAt + 2} gain={0.8} rate={1.1} />
      <Sfx name="pop" at={dev - 2} rate={0.9} />
      <Sfx name="click" at={strike - 2} gain={0.9} />
    </AbsoluteFill>
  );
};
void GradText;
