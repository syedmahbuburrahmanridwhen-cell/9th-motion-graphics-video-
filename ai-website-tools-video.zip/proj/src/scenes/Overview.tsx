import React from "react";
import { AbsoluteFill, useCurrentFrame } from "remotion";
import { theme } from "../theme";
import { Sfx, useIdle, useScene, useSpr, useTween } from "../motion";
import { Counter, Enter, Glass, GradText, Icon, Words } from "../components";
import { Pos } from "../layout";

const CX = 960, CY = 560;

export const Overview: React.FC = () => {
  const { at, dur } = useScene();
  const frame = useCurrentFrame();
  const spr = useSpr();
  const tw = useTween();
  const idle = useIdle();

  const a3 = at(3, 0);
  const a4 = at(4, 0);
  const orbOut = tw(a4 - 4, a4 + 8, 0, 1, theme.ease.in);
  const ringIn = spr(a4 + 2, theme.spring.bouncy);
  const prog = tw(a4 + 4, dur - 6, 0, 1, theme.ease.inOut);
  const shrink = tw(a4, a4 + 20, 0, 1, theme.ease.inOut);
  const ang0 = frame * 0.28;
  const rx = 560 - 130 * shrink, ry = 230 - 20 * shrink;

  const nodes = [0, 1, 2].map((i) => {
    const th = ((-90 + i * 120 + ang0) * Math.PI) / 180;
    return { x: CX + rx * Math.cos(th), y: CY + ry * Math.sin(th) };
  });

  return (
    <AbsoluteFill>
      {/* heading */}
      <Pos x={CX} y={120}><Words text="তিনটা AI tool" delay={a3} per={6} size={124} hi={[1]} /></Pos>

      {/* connectors with traveling pulses */}
      <svg width={1920} height={1080} style={{ position: "absolute", inset: 0 }}>
        {nodes.map((n, i) => {
          const p = tw(a3 + 14 + i * 5, a3 + 40 + i * 5, 0, 1, theme.ease.inOut);
          const t = ((frame + i * 20) % 50) / 50;
          return (
            <g key={i} opacity={0.9}>
              <line x1={CX} y1={CY} x2={CX + (n.x - CX) * p} y2={CY + (n.y - CY) * p} stroke={theme.colors.accent} strokeWidth={3} strokeDasharray="10 12" strokeDashoffset={-frame * 1.2} opacity={0.55} />
              <circle cx={CX + (n.x - CX) * t * p} cy={CY + (n.y - CY) * t * p} r={8} fill={theme.colors.accent} opacity={p} />
            </g>
          );
        })}
      </svg>

      {/* satellites */}
      {nodes.map((n, i) => {
        const p = spr(a3 + 10 + i * 6, theme.spring.bouncy);
        return (
          <Pos key={i} x={n.x} y={n.y} style={{ opacity: Math.min(1, p * 1.4), transform: `translate(-50%,-50%) scale(${0.3 + 0.7 * p}) translateY(${Math.sin(frame / 26 + i * 2) * 6}px)` }}>
            <Glass w={290} h={160} radius={30} style={{ display: "flex", alignItems: "center", justifyContent: "space-between", padding: "0 34px" }}>
              <GradText style={{ fontFamily: theme.fonts.display, fontWeight: 700, fontSize: 84, lineHeight: 1.1 }}>{`0${i + 1}`}</GradText>
              <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 2 }}>
                <Icon name="spark" size={46} color={theme.colors.accent} />
                <span style={{ fontFamily: theme.fonts.display, fontWeight: 600, fontSize: 34, color: theme.colors.textDim }}>AI tool</span>
              </div>
            </Glass>
          </Pos>
        );
      })}

      {/* center A: voice orb */}
      <Pos x={CX} y={CY} style={{ opacity: 1 - orbOut, transform: `translate(-50%,-50%) scale(${(0.3 + 0.7 * spr(a3 + 4, theme.spring.bouncy)) * (1 - orbOut * 0.7)})` }}>
        {[0, 1, 2].map((k) => {
          const t = ((frame / 42 + k / 3) % 1);
          return <div key={k} style={{ position: "absolute", left: -150 + 0, top: -150, width: 300, height: 300, borderRadius: "50%", border: `3px solid ${theme.colors.accent}`, opacity: (1 - t) * 0.6, transform: `scale(${0.5 + t * 1.3})` }} />;
        })}
        <div style={{ width: 210, height: 210, marginLeft: -105, marginTop: -105, borderRadius: "50%", background: theme.gradient.hero, display: "flex", alignItems: "center", justifyContent: "center", boxShadow: `0 0 90px ${theme.colors.glow}`, transform: `scale(${1 + idle.s - 1})` }}>
          <Icon name="mic" size={104} color={theme.colors.white} stroke={2} />
        </div>
      </Pos>

      {/* center B: 20-second ring */}
      <Pos x={CX} y={CY} style={{ opacity: Math.min(1, ringIn * 1.5), transform: `translate(-50%,-50%) scale(${0.4 + 0.6 * ringIn})` }}>
        <svg width={360} height={360} viewBox="0 0 360 360" style={{ position: "absolute", left: -180, top: -180, filter: `drop-shadow(0 0 28px ${theme.colors.glow})` }}>
          <circle cx={180} cy={180} r={150} fill="rgba(7,11,26,0.7)" stroke={theme.colors.borderSoft} strokeWidth={18} />
          <circle cx={180} cy={180} r={150} fill="none" stroke="url(#rg)" strokeWidth={18} strokeLinecap="round" pathLength={1} strokeDasharray={1} strokeDashoffset={1 - prog} transform="rotate(-90 180 180)" />
          <defs><linearGradient id="rg" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stopColor={theme.colors.primary} /><stop offset="1" stopColor={theme.colors.accent} /></linearGradient></defs>
        </svg>
        <div style={{ position: "absolute", left: -150, top: -112, width: 300, textAlign: "center" }}>
          <Counter to={20} start={a4 + 4} end={dur - 8} size={150} style={{ color: theme.colors.text }} />
          <div style={{ fontFamily: theme.fonts.display, fontWeight: 600, fontSize: 44, color: theme.colors.accent, marginTop: -4 }}>সেকেন্ড</div>
        </div>
      </Pos>

      {/* captions */}
      <Pos x={CX} y={975}>
        <div style={{ position: "relative" }}>
          <Enter delay={a3 + 24} exitAt={a4 - 8} style={{ display: "flex", alignItems: "center", gap: 22, justifyContent: "center" }}>
            <Icon name="mic" size={60} color={theme.colors.accent} />
            <Words text="শুধু মুখে বলে দেবেন" delay={a3 + 26} per={4} size={78} />
          </Enter>
          <div style={{ position: "absolute", inset: 0, display: "flex", justifyContent: "center" }}>
            <Words text="পুরো website একদম" delay={a4 + 6} per={5} size={78} hi={[1]} />
          </div>
        </div>
      </Pos>

      <Sfx name="pop" at={a3 + 8} rate={0.9} />
      <Sfx name="pop" at={a3 + 14} rate={1.0} />
      <Sfx name="pop" at={a3 + 20} rate={1.1} />
      <Sfx name="whoosh" at={a4 - 4} gain={0.8} />
    </AbsoluteFill>
  );
};
