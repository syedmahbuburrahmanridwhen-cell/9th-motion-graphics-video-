import React from "react";
import { AbsoluteFill, Img, staticFile, useCurrentFrame } from "remotion";
import { theme } from "../theme";
import { Sfx, useIdle, useScene, useSpr, useTween } from "../motion";
import { Cursor, Enter, Glass, GradText, Icon, Ripple, Words } from "../components";
import { Pos } from "../layout";

export const Follow: React.FC = () => {
  const { at, dur } = useScene();
  const frame = useCurrentFrame();
  const spr = useSpr();
  const tw = useTween();
  const idle = useIdle();

  const a22 = at(22, 0), a23 = at(23, 0), a24 = at(24, 0);
  const lockAt = at(22, 0.55);
  const part1Out = at(23, 0.42);
  const avatarAt = part1Out + 4;
  const textAt = at(23, 0.5);
  const btnAt = a24 - 4;
  const pressAt = at(24, 0.5);

  // plane flying along an arc, carrying the link chip
  const fly = tw(a22, a22 + 30, 0, 1, theme.ease.out);
  const px = -160 + fly * (960 + 160), py = 330 + Math.sin(fly * Math.PI) * -150 + (1 - fly) * 160;
  const lockP = spr(lockAt, theme.spring.bouncy);
  const shake = Math.sin((frame - lockAt) * 2.4) * 10 * Math.max(0, 1 - (frame - lockAt) / 18) * (frame >= lockAt ? 1 : 0);
  const chipDim = tw(lockAt, lockAt + 8, 1, 0.45);

  const avatarP = spr(avatarAt, theme.spring.bouncy);
  const btnP = spr(btnAt, theme.spring.bouncy);
  const press = tw(pressAt - 3, pressAt + 2, 0, 1) * (1 - tw(pressAt + 2, pressAt + 9, 0, 1));
  const done = spr(pressAt + 3, theme.spring.bouncy);
  const bell = Math.sin((frame - pressAt) * 1.1) * 18 * Math.max(0, 1 - (frame - pressAt - 4) / 40) * (frame > pressAt + 4 ? 1 : 0);
  const cur = tw(pressAt - 20, pressAt - 3, 0, 1, theme.ease.inOut);

  return (
    <AbsoluteFill>
      {/* part 1: link sent… but locked without a follow */}
      <Pos x={px} y={frame < lockAt ? py : 330} style={{ opacity: 1 - tw(part1Out - 2, part1Out + 8, 0, 1, theme.ease.in), transform: `translate(-50%,-50%) rotate(${(1 - fly) * -14}deg) scale(${1 - tw(part1Out - 2, part1Out + 8, 0, 0.1)})` }}>
        <Glass radius={999} style={{ display: "flex", alignItems: "center", gap: 26, padding: "10px 64px 10px 40px", opacity: chipDim }}>
          <Icon name="link" size={80} color={theme.colors.accent} stroke={2.2} />
          <span style={{ fontFamily: theme.fonts.display, fontWeight: 700, fontSize: 96, color: theme.colors.text, lineHeight: 1.3 }}>link</span>
          <Icon name="plane" size={70} color={theme.colors.accent} stroke={2.2} style={{ opacity: 1 - fly }} />
        </Glass>
      </Pos>
      <Pos x={1230} y={330} style={{ opacity: Math.min(1, lockP * 1.5) * (1 - tw(part1Out - 2, part1Out + 8, 0, 1, theme.ease.in)), transform: `translate(-50%,-50%) translateX(${shake}px) scale(${2.2 - 1.2 * lockP})` }}>
        <div style={{ width: 190, height: 190, borderRadius: 95, background: theme.gradient.hero, display: "flex", alignItems: "center", justifyContent: "center", boxShadow: `0 0 80px ${theme.colors.glow}` }}>
          <Icon name="lock" size={104} color={theme.colors.white} stroke={2.2} />
        </div>
      </Pos>
      <Pos x={960} y={640}><Words text="Follow না দিলে" delay={at(22, 0.38)} per={6} size={136} hi={[0]} exitAt={part1Out - 4} /></Pos>
      <Pos x={960} y={830}><Words text="link যাবে না" delay={a23 - 2} per={6} size={136} hi={[1]} exitAt={part1Out - 4} /></Pos>

      {/* part 2: avatar, message, follow button */}
      <Pos x={960} y={290 + idle.y} style={{ opacity: Math.min(1, avatarP * 1.4), transform: `translate(-50%,-50%) scale(${0.3 + 0.7 * avatarP})` }}>
        {[0, 1].map((k) => {
          const t = (frame / 56 + k / 2) % 1;
          return <div key={k} style={{ position: "absolute", left: -170, top: -170, width: 340, height: 340, borderRadius: "50%", border: `3px solid ${theme.colors.accent}`, opacity: (1 - t) * 0.55, transform: `scale(${0.8 + t * 0.7})` }} />;
        })}
        <div style={{ width: 290, height: 290, marginLeft: -145, marginTop: -145, borderRadius: "50%", padding: 8, background: theme.gradient.hero, boxSizing: "border-box", boxShadow: `0 0 90px ${theme.colors.glow}` }}>
          <Img src={staticFile("profile.jpg")} style={{ width: "100%", height: "100%", borderRadius: "50%", objectFit: "cover", border: `6px solid ${theme.colors.bg}`, boxSizing: "border-box", display: "block" }} />
        </div>
      </Pos>
      <Pos x={960} y={575}><Words text="এমন আরও কাজের video" delay={textAt} per={5} size={104} hi={[3]} /></Pos>

      <Pos x={960} y={800} style={{ opacity: Math.min(1, btnP * 1.4), transform: `translate(-50%,-50%) scale(${(0.4 + 0.6 * btnP) * (1 - press * 0.1)})` }}>
        <div style={{ position: "relative", width: 640, height: 150 }}>
          <div style={{ position: "absolute", inset: 0, borderRadius: 75, background: theme.gradient.hero, display: "flex", alignItems: "center", justifyContent: "center", gap: 22, fontFamily: theme.fonts.display, fontWeight: 700, fontSize: 80, color: theme.colors.white, boxShadow: `0 20px 70px ${theme.colors.glow}, 0 0 0 ${8 + 6 * Math.sin(frame / 8)}px ${theme.colors.glowSoft}`, opacity: 1 - Math.min(1, done * 2), lineHeight: 1.3 }}>
            <Icon name="userplus" size={76} color={theme.colors.white} stroke={2.2} />Follow
          </div>
          <div style={{ position: "absolute", inset: 0, borderRadius: 75, background: theme.colors.surfaceStrong, border: `3px solid ${theme.colors.accent}`, display: "flex", alignItems: "center", justifyContent: "center", gap: 22, fontFamily: theme.fonts.display, fontWeight: 700, fontSize: 70, color: theme.colors.text, opacity: Math.min(1, done * 1.6), transform: `scale(${0.7 + 0.3 * done})`, boxShadow: `0 0 60px ${theme.colors.glowAccent}`, lineHeight: 1.3 }}>
            <Icon name="check" size={70} color={theme.colors.accent} stroke={3} />Following
            <div style={{ transform: `rotate(${bell}deg)`, transformOrigin: "50% 10%" }}><Icon name="bell" size={64} color={theme.colors.accent} stroke={2.2} /></div>
          </div>
        </div>
      </Pos>
      <Ripple at={pressAt} x={960} y={800} size={360} />
      <Cursor x={960 + 120 + (1 - cur) * 200} y={800 + 20 + (1 - cur) * 140} press={press} opacity={cur * (1 - tw(pressAt + 14, pressAt + 24, 0, 1))} />

      <Sfx name="whoosh" at={a22 - 2} gain={0.8} rate={1.05} />
      <Sfx name="thud" at={lockAt - 3} gain={0.9} rate={1.1} />
      <Sfx name="pop" at={avatarAt - 2} rate={0.95} />
      <Sfx name="pop" at={btnAt - 2} rate={1.08} />
      <Sfx name="click" at={pressAt - 2} />
      <Sfx name="chime" at={pressAt + 2} rate={1.05} />
    </AbsoluteFill>
  );
};

