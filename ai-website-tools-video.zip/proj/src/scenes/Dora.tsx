import React from "react";
import { AbsoluteFill, useCurrentFrame } from "remotion";
import { theme } from "../theme";
import { Sfx, useScene, useSpr, useTween } from "../motion";
import { Enter, Glass, GradText, Icon, LogoMark, NumberBadge, Pill, Words } from "../components";
import { Pos } from "../layout";

const N = 6;

/** small website thumbnail on a 3D carousel panel */
const Panel: React.FC<{ k: number }> = ({ k }) => {
  const t = theme.colors.tints;
  return (
    <Glass w={380} h={250} radius={26} pad={18} style={{ background: "linear-gradient(150deg, rgba(20,30,70,0.92), rgba(10,16,40,0.92))" }}>
      <div style={{ display: "flex", gap: 8, marginBottom: 14 }}>
        {[0, 1, 2].map((i) => <div key={i} style={{ width: 11, height: 11, borderRadius: 6, background: theme.colors.surfaceStrong }} />)}
        <div style={{ flex: 1 }} /><div style={{ width: 70, height: 11, borderRadius: 6, background: theme.colors.surface }} />
      </div>
      {k % 3 === 0 && (<><div style={{ height: 118, borderRadius: 14, background: `linear-gradient(135deg, ${t[0]}, ${t[1]})` }} /><div style={{ display: "flex", gap: 10, marginTop: 14 }}>{[0, 1, 2].map((i) => <div key={i} style={{ flex: 1, height: 52, borderRadius: 10, background: theme.colors.surfaceStrong }} />)}</div></>)}
      {k % 3 === 1 && (<div style={{ display: "flex", gap: 14 }}><div style={{ flex: 1 }}><div style={{ height: 22, width: "90%", borderRadius: 11, background: theme.colors.text, opacity: 0.85 }} /><div style={{ height: 22, width: "60%", borderRadius: 11, background: theme.colors.text, opacity: 0.85, marginTop: 12 }} /><div style={{ height: 40, width: 110, borderRadius: 20, background: theme.gradient.hero, marginTop: 28 }} /></div><div style={{ width: 150, height: 160, borderRadius: 74, background: `radial-gradient(circle at 35% 30%, ${t[4]}, ${t[3]})` }} /></div>)}
      {k % 3 === 2 && (<div style={{ display: "flex", gap: 12 }}>{[0, 1, 2].map((i) => <div key={i} style={{ flex: 1, height: 170, borderRadius: 14, background: `linear-gradient(180deg, ${t[(k + i) % 6]}, ${t[(k + i + 3) % 6]})`, transform: `translateY(${i === 1 ? -12 : 0}px)` }} />)}</div>)}
    </Glass>
  );
};

export const Dora: React.FC = () => {
  const { at } = useScene();
  const frame = useCurrentFrame();
  const spr = useSpr();
  const tw = useTween();

  const a11 = at(11, 0), a12 = at(12, 0), a13 = at(13, 0), a14 = at(14, 0);
  const ringP = spr(a11 + 14, theme.spring.soft);
  const spin = tw(a11 + 6, a11 + 80, -140, 0, theme.ease.out) + frame * 0.55 + tw(a12, a12 + 30, 0, 1) * (frame - a12) * 0.45;
  const spread = 1 + tw(a12, a12 + 24, 0, 0.12, theme.ease.out);
  const tilt = -6 - tw(a12, a12 + 24, 0, 4);

  const strikeP = tw(at(14, 0.45), at(14, 0.45) + 12, 0, 1);
  const priceP = spr(at(13, 0.5), theme.spring.bouncy);
  const capA = a11 + 18;

  return (
    <AbsoluteFill>
      {/* header row: badge · logo · title */}
      <Pos x={560} y={165}><NumberBadge n="02" delay={a11 - 2} /></Pos>
      <Pos x={960} y={170}><LogoMark kind="dora" size={270} delay={a11 + 2} /></Pos>
      <Pos x={1380} y={175}><Words text="Dora AI" delay={a11 + 10} per={6} size={108} hi={[1]} /></Pos>

      {/* 3D carousel ring */}
      <div style={{ position: "absolute", left: 0, right: 0, top: 250, height: 520, perspective: 1800, perspectiveOrigin: "50% 40%", opacity: Math.min(1, ringP * 1.4) }}>
        <div style={{ position: "absolute", left: 960, top: 260, width: 0, height: 0, transformStyle: "preserve-3d", transform: `scale(${0.5 + 0.36 * ringP}) rotateX(${tilt}deg) rotateY(${spin}deg)` }}>
          {Array.from({ length: N }).map((_, k) => {
            const ang = (360 / N) * k;
            const world = ((ang + spin) % 360 + 360) % 360;
            const depth = (Math.cos((world * Math.PI) / 180) + 1) / 2; // 1 = front
            return (
              <div key={k} style={{ position: "absolute", left: -190, top: -125, transform: `rotateY(${ang}deg) translateZ(${560 * spread}px)`, opacity: 0.35 + 0.65 * depth, filter: `brightness(${0.55 + 0.45 * depth})` }}>
                <Panel k={k} />
              </div>
            );
          })}
        </div>
        {/* floor glow */}
        <div style={{ position: "absolute", left: 360, right: 360, bottom: 20, height: 90, borderRadius: "50%", background: `radial-gradient(ellipse, ${theme.colors.glow} 0%, transparent 70%)`, opacity: 0.7 }} />
      </div>

      {/* captions */}
      <Pos x={960} y={935}>
        <div style={{ position: "relative", height: 130, width: 1500 }}>
          {/* c11: coding ছাড়াই */}
          <div style={{ position: "absolute", inset: 0, display: "flex", justifyContent: "center", alignItems: "center" }}>
            <Enter delay={capA} exitAt={a12 - 8} cfg={theme.spring.bouncy} style={{ display: "flex", alignItems: "center", gap: 24 }}>
              <div style={{ position: "relative", width: 96, height: 96 }}>
                <Icon name="code" size={96} color={theme.colors.textDim} />
                <div style={{ position: "absolute", left: -6, top: 44, width: 108, height: 8, borderRadius: 4, background: theme.colors.primary, transform: "rotate(-45deg)", boxShadow: `0 0 20px ${theme.colors.glow}` }} />
              </div>
              <Words text="coding ছাড়াই" delay={capA + 2} per={5} size={92} hi={[0]} />
            </Enter>
          </div>
          {/* c12: 3D animation website */}
          <div style={{ position: "absolute", inset: 0, display: "flex", justifyContent: "center", alignItems: "center" }}>
            <Words text="3D animation website" delay={a12 + 2} per={5} size={96} hi={[0]} exitAt={at(13, 0.4) - 8} />
          </div>
          {/* c13–14: price struck */}
          <div style={{ position: "absolute", inset: 0, display: "flex", justifyContent: "center", alignItems: "center", opacity: Math.min(1, priceP * 1.5), transform: `scale(${0.7 + 0.3 * priceP})` }}>
            <Glass radius={999} style={{ padding: "6px 56px 6px 40px", display: "flex", alignItems: "center", gap: 26, opacity: 1 - strikeP * 0.4 }}>
              <Icon name="tag" size={70} color={theme.colors.accent} />
              <div style={{ position: "relative", fontFamily: theme.fonts.display, fontWeight: 700, fontSize: 90, lineHeight: 1.3, color: theme.colors.text }}>
                হাজার হাজার টাকা
                <div style={{ position: "absolute", left: -12, top: "54%", height: 12, width: `${strikeP * 108}%`, borderRadius: 6, background: theme.colors.primary, boxShadow: `0 0 30px ${theme.colors.glow}`, transform: "rotate(-2deg)" }} />
              </div>
            </Glass>
          </div>
        </div>
      </Pos>

      <Sfx name="chime" at={a11 + 0} />
      <Sfx name="pop" at={a11 + 12} rate={0.95} />
      <Sfx name="whoosh" at={a11 + 10} gain={0.7} rate={0.95} />
      <Sfx name="pop" at={capA - 2} rate={1.05} />
      <Sfx name="pop" at={a12 - 1} rate={1.1} />
      <Sfx name="pop" at={at(13, 0.5) - 2} rate={0.9} />
      <Sfx name="click" at={at(14, 0.45) - 2} />
    </AbsoluteFill>
  );
};
void GradText;
