import React, { useEffect, useState } from "react";
import { AbsoluteFill, Audio, Img, continueRender, delayRender, getRemotionEnvironment, interpolate, random, spring, staticFile, useCurrentFrame, useVideoConfig } from "remotion";
import { theme } from "./theme";
import { CL, useIdle, useScene, useSpr, useTween } from "./motion";
import { SCENES, sceneStart } from "./timeline";
import { VOICEOVER } from "./config";

/* ================================================================ Background (layer 1) */
export const Bg: React.FC = () => {
  const frame = useCurrentFrame();
  // smooth float scene index → blobs glide between scenes (parallax continuity)
  let idx = 0;
  for (let i = 1; i < SCENES.length; i++) idx += interpolate(frame, [sceneStart(i) - 12, sceneStart(i) + 24], [0, 1], { easing: theme.ease.inOut, ...CL });
  const xs = [[-300, 1500, 800, 100, 1300, 300, 900], [1300, 100, 1500, 1500, 200, 1400, 400]];
  const ys = [[-300, 600, -200, 700, -250, 650, 100], [650, -250, 700, 0, 700, -200, 650]];
  const p = (a: number[]) => interpolate(idx, a.map((_, k) => k), a, CL);
  const drift = (k: number) => Math.sin(frame / (55 + k * 13)) * 50;
  const gridShift = (frame * 1.2) % 80;
  return (
    <AbsoluteFill style={{ background: `linear-gradient(180deg, ${theme.colors.bg} 0%, ${theme.colors.bgAlt} 100%)` }}>
      <div style={{ position: "absolute", width: 1500, height: 1500, borderRadius: "50%", left: p(xs[0]) - 300 + drift(0), top: p(ys[0]) - 300 + drift(1), background: `radial-gradient(circle, ${theme.colors.glow} 0%, transparent 62%)`, opacity: 0.55 }} />
      <div style={{ position: "absolute", width: 1200, height: 1200, borderRadius: "50%", left: p(xs[1]) - 300 - drift(2), top: p(ys[1]) - 300 + drift(3), background: `radial-gradient(circle, ${theme.colors.glowAccent} 0%, transparent 65%)`, opacity: 0.4 }} />
      {/* dot grid with soft radial mask */}
      <AbsoluteFill style={{ backgroundImage: `radial-gradient(${theme.colors.borderSoft} 2px, transparent 2.5px)`, backgroundSize: "80px 80px", backgroundPosition: `${gridShift}px ${gridShift * 0.6}px`, WebkitMaskImage: "radial-gradient(ellipse at 50% 50%, black 15%, transparent 75%)", maskImage: "radial-gradient(ellipse at 50% 50%, black 15%, transparent 75%)", opacity: 0.9 }} />
      <Particles />
    </AbsoluteFill>
  );
};

const Particles: React.FC = () => {
  const frame = useCurrentFrame();
  return (
    <AbsoluteFill>
      {Array.from({ length: 34 }).map((_, i) => {
        const x = random(`px${i}`) * 1920, size = 2 + random(`ps${i}`) * 4, speed = 0.25 + random(`pv${i}`) * 0.6;
        const y = 1180 - ((frame * speed * 1.4 + random(`py${i}`) * 1300) % 1300);
        const tw = 0.25 + 0.55 * Math.abs(Math.sin(frame / (18 + i % 9) + i));
        const c = i % 5 === 0 ? theme.colors.accent : theme.colors.text;
        return <div key={i} style={{ position: "absolute", left: x + Math.sin(frame / 40 + i) * 24, top: y, width: size, height: size, borderRadius: "50%", background: c, opacity: tw * 0.55, boxShadow: i % 5 === 0 ? `0 0 12px ${theme.colors.accent}` : "none" }} />;
      })}
    </AbsoluteFill>
  );
};

/* ================================================================ Grade / grain / vignette (top layers) */
export const Grade: React.FC = () => (
  <AbsoluteFill style={{ pointerEvents: "none" }}>
    <AbsoluteFill style={{ backgroundColor: theme.colors.primary, mixBlendMode: "soft-light", opacity: 0.16 }} />
    <AbsoluteFill style={{ background: "linear-gradient(180deg, rgba(0,0,0,0.12), transparent 26%, transparent 74%, rgba(0,0,0,0.22))" }} />
  </AbsoluteFill>
);
export const Grain: React.FC = () => {
  const frame = useCurrentFrame();
  const noise = `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='220' height='220'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='2'/%3E%3C/filter%3E%3Crect width='220' height='220' filter='url(%23n)' opacity='0.5'/%3E%3C/svg%3E")`;
  return <AbsoluteFill style={{ pointerEvents: "none", backgroundImage: noise, backgroundSize: "220px", backgroundPosition: `${(frame * 7) % 220}px ${(frame * 13) % 220}px`, opacity: 0.06, mixBlendMode: "overlay" }} />;
};
export const Vignette: React.FC = () => (
  <AbsoluteFill style={{ pointerEvents: "none", background: "radial-gradient(ellipse at center, transparent 54%, rgba(0,0,0,0.38) 100%)" }} />
);

/* ================================================================ Scene transition panel */
export const CutWipe: React.FC<{ cut: number }> = ({ cut }) => {
  const frame = useCurrentFrame();
  const W = 3200;
  const left = interpolate(frame, [cut - 12, cut + 12], [-W - 160, 1920 + 160], { easing: theme.ease.wipe, ...CL });
  if (frame < cut - 13 || frame > cut + 13) return null;
  return (
    <AbsoluteFill style={{ overflow: "hidden", pointerEvents: "none" }}>
      <div style={{ position: "absolute", top: -200, height: 1480, width: W, left, transform: "skewX(-12deg)", background: `linear-gradient(90deg, ${theme.colors.bgDeep} 0%, ${theme.colors.bg} 100%)`, boxShadow: `120px 0 0 -0px ${theme.colors.accent}, 190px 0 0 0 ${theme.colors.primary}` }}>
        <div style={{ position: "absolute", right: 0, top: 0, bottom: 0, width: 420, background: `linear-gradient(90deg, transparent, ${theme.colors.glow})` }} />
      </div>
    </AbsoluteFill>
  );
};

/* ================================================================ Entrance wrapper */
type Dir = "up" | "down" | "left" | "right" | "scale";
export const Enter: React.FC<{ delay?: number; dir?: Dir; dist?: number; exitAt?: number; cfg?: { damping: number; stiffness: number; mass: number }; style?: React.CSSProperties; children: React.ReactNode }> = ({ delay = 0, dir = "up", dist = 56, exitAt, cfg = theme.spring.smooth, style, children }) => {
  const spr = useSpr();
  const tw = useTween();
  const p = spr(delay, cfg);
  const q = exitAt === undefined ? 0 : tw(exitAt, exitAt + 10, 0, 1, theme.ease.in);
  const k = (1 - p) * dist;
  const dx = dir === "left" ? -k : dir === "right" ? k : 0;
  const dy = dir === "up" ? k : dir === "down" ? -k : 0;
  const sc = (dir === "scale" ? 0.6 + 0.4 * p : 0.93 + 0.07 * p) * (1 - q * 0.08);
  return (
    <div style={{ opacity: Math.min(1, p * 1.3) * (1 - q), transform: `translate(${dx}px, ${dy - q * 30}px) scale(${sc})`, ...style }}>{children}</div>
  );
};

/* ================================================================ Text */
export const GradText: React.FC<{ children: React.ReactNode; style?: React.CSSProperties }> = ({ children, style }) => (
  <span style={{ background: theme.gradient.hero, WebkitBackgroundClip: "text", backgroundClip: "text", color: "transparent", WebkitTextFillColor: "transparent", ...style }}>{children}</span>
);

/** Word-by-word masked rise. Splits ONLY on spaces — Bengali clusters are never broken. */
export const Words: React.FC<{ text: string; delay?: number; per?: number; size?: number; weight?: number; color?: string; hi?: number[]; align?: "left" | "center" | "right"; exitAt?: number; gap?: number; style?: React.CSSProperties }> = ({ text, delay = 0, per = 4, size = theme.size.title, weight = 700, color = theme.colors.text, hi = [], align = "center", exitAt, gap, style }) => {
  const spr = useSpr();
  const tw = useTween();
  const q = exitAt === undefined ? 0 : tw(exitAt, exitAt + 10, 0, 1, theme.ease.in);
  return (
    <div style={{ display: "flex", flexWrap: "wrap", justifyContent: align === "center" ? "center" : align === "left" ? "flex-start" : "flex-end", columnGap: gap ?? Math.round(size * 0.26), fontFamily: theme.fonts.display, fontSize: size, fontWeight: weight, lineHeight: 1.3, letterSpacing: 0, color, ...style }}>
      {text.split(" ").map((w, i) => {
        const p = spr(delay + i * per, theme.spring.snappy);
        const isHi = hi.includes(i);
        return (
          <span key={i} style={{ display: "inline-block", overflow: "hidden", padding: "0.2em 0.06em 0.3em", margin: "-0.2em -0.06em -0.3em" }}>
            <span style={{ display: "inline-block", opacity: Math.min(1, p * 1.4) * (1 - q), transform: `translateY(${(1 - p) * 105 + q * -40}%) scale(${0.9 + 0.1 * p})`, transformOrigin: "50% 100%" }}>
              {isHi ? <GradText>{w}</GradText> : w}
            </span>
          </span>
        );
      })}
    </div>
  );
};

/** Bengali-safe "typing": a mask sweep word by word (no letter splitting) with a caret. */
export const SweepType: React.FC<{ text: string; start: number; end: number; size: number; color?: string; caret?: boolean; weight?: number }> = ({ text, start, end, size, color = theme.colors.text, caret = true, weight = 600 }) => {
  const frame = useCurrentFrame();
  const words = text.split(" ");
  const per = (end - start) / words.length;
  const idx = Math.min(words.length, Math.max(0, (frame - start) / per));
  const full = Math.floor(idx), part = idx - full;
  const blink = Math.floor(frame / 12) % 2 === 0;
  return (
    <div style={{ display: "flex", alignItems: "center", columnGap: size * 0.26, fontFamily: theme.fonts.display, fontSize: size, fontWeight: weight, color, lineHeight: 1.3, whiteSpace: "nowrap" }}>
      {words.map((w, i) => {
        const reveal = i < full ? 1 : i === full ? part : 0;
        return <span key={i} style={{ display: "inline-block", overflow: "hidden", padding: "0.2em 0.04em 0.3em", margin: "-0.2em -0.04em -0.3em", clipPath: `inset(0 ${(1 - reveal) * 100}% 0 0)`, opacity: reveal > 0 ? 1 : 0 }}>{w}</span>;
      })}
      {caret && <span style={{ width: Math.max(4, size * 0.07), height: size * 0.95, background: theme.colors.accent, opacity: blink || frame < start || idx < words.length ? (frame >= start ? 1 : 0) : 0.0, borderRadius: 3, marginLeft: -size * 0.1 }} />}
    </div>
  );
};

/** Latin-only typewriter (used for the English comment "AI"). */
export const TypeChars: React.FC<{ text: string; start: number; per?: number; size: number; color?: string }> = ({ text, start, per = 7, size, color = theme.colors.text }) => {
  const frame = useCurrentFrame();
  const n = Math.max(0, Math.min(text.length, Math.floor((frame - start) / per) + (frame >= start ? 1 : 0)));
  const blink = Math.floor(frame / 12) % 2 === 0;
  return (
    <span style={{ fontFamily: theme.fonts.display, fontWeight: 600, fontSize: size, color, lineHeight: 1.3 }}>
      {text.slice(0, n)}
      <span style={{ display: "inline-block", width: 4, height: size * 0.85, marginLeft: 4, background: theme.colors.accent, verticalAlign: "middle", opacity: blink ? 1 : 0.1 }} />
    </span>
  );
};

/** Counter roll — tabular numbers (only for numbers that exist in the script). */
export const Counter: React.FC<{ to: number; start: number; end: number; size: number; style?: React.CSSProperties }> = ({ to, start, end, size, style }) => {
  const tw = useTween();
  const v = tw(start, end, 0, to, theme.ease.inOut);
  return <span style={{ fontFamily: theme.fonts.display, fontWeight: 700, fontSize: size, fontVariantNumeric: "tabular-nums", lineHeight: 1.1, ...style }}>{Math.round(v)}</span>;
};

/* ================================================================ Surfaces */
export const Glass: React.FC<{ w?: number | string; h?: number | string; radius?: number; pad?: number; style?: React.CSSProperties; children?: React.ReactNode }> = ({ w, h, radius = theme.radius.md, pad = 0, style, children }) => (
  <div style={{ width: w, height: h, borderRadius: radius, padding: pad, boxSizing: "border-box", background: theme.gradient.card, border: `1.5px solid ${theme.colors.border}`, boxShadow: `0 30px 70px -20px ${theme.colors.shadow}, inset 0 1px 0 rgba(255,255,255,0.18)`, ...style }}>{children}</div>
);

export const Pill: React.FC<{ children: React.ReactNode; style?: React.CSSProperties; hero?: boolean }> = ({ children, style, hero }) => (
  <div style={{ display: "inline-flex", alignItems: "center", gap: 14, padding: "14px 30px", borderRadius: 999, fontFamily: theme.fonts.display, fontWeight: 600, fontSize: theme.size.small, color: hero ? theme.colors.white : theme.colors.text, background: hero ? theme.gradient.hero : theme.colors.surfaceStrong, border: `1.5px solid ${hero ? "transparent" : theme.colors.border}`, boxShadow: hero ? `0 12px 40px ${theme.colors.glow}` : "none", ...style }}>{children}</div>
);

export const BrowserWindow: React.FC<{ w: number; h: number; children?: React.ReactNode; url?: string; style?: React.CSSProperties }> = ({ w, h, children, url = "", style }) => (
  <Glass w={w} h={h} radius={30} style={{ overflow: "hidden", ...style }}>
    <div style={{ height: 66, display: "flex", alignItems: "center", gap: 12, padding: "0 26px", borderBottom: `1.5px solid ${theme.colors.borderSoft}`, background: "rgba(255,255,255,0.04)" }}>
      {[0, 1, 2].map((i) => <div key={i} style={{ width: 16, height: 16, borderRadius: 8, background: i === 2 ? theme.colors.accent : theme.colors.surfaceStrong }} />)}
      <div style={{ marginLeft: 22, height: 34, flex: 1, maxWidth: 520, borderRadius: 17, background: theme.colors.surface, display: "flex", alignItems: "center", padding: "0 18px", fontFamily: theme.fonts.display, fontSize: 22, color: theme.colors.textDim }}>{url}</div>
    </div>
    <div style={{ position: "relative", width: "100%", height: h - 66 }}>{children}</div>
  </Glass>
);

/* ================================================================ Logos */
export const LogoMark: React.FC<{ kind: "framer" | "dora" | "hostinger"; size: number; delay?: number; float?: boolean }> = ({ kind, size, delay = 0, float = true }) => {
  const spr = useSpr();
  const id = useIdle(1, delay);
  const p = spr(delay, theme.spring.bouncy);
  const pw = spr(delay + 2, theme.spring.soft);
  const isH = kind === "hostinger";
  const w = isH ? size : size, h = isH ? size * 0.5 : size;
  return (
    <div style={{ position: "relative", width: w, height: h, opacity: Math.min(1, p * 1.5), transform: `scale(${0.4 + 0.6 * p}) rotate(${(1 - p) * -14 + (float ? id.r : 0)}deg) translateY(${float ? id.y : 0}px)` }}>
      <div style={{ position: "absolute", inset: -size * 0.28, borderRadius: "50%", background: `radial-gradient(circle, ${theme.colors.glow} 0%, transparent 62%)`, opacity: pw * 0.8 }} />
      {isH ? (
        <div style={{ position: "relative", width: w, height: h, borderRadius: 34, background: theme.colors.white, display: "flex", alignItems: "center", justifyContent: "center", boxShadow: `0 30px 70px -18px ${theme.colors.shadow}, 0 0 0 1.5px ${theme.colors.border}` }}>
          <Img src={staticFile("hostinger.png")} style={{ width: "76%", height: "auto" }} />
        </div>
      ) : (
        <Img src={staticFile(`${kind}.png`)} style={{ position: "relative", width: w, height: h, filter: "drop-shadow(0 24px 40px rgba(0,0,0,0.5))" }} />
      )}
    </div>
  );
};

export const NumberBadge: React.FC<{ n: string; delay?: number }> = ({ n, delay = 0 }) => {
  const spr = useSpr();
  const p = spr(delay, theme.spring.bouncy);
  return (
    <div style={{ display: "inline-flex", alignItems: "baseline", gap: 16, padding: "10px 34px 14px", borderRadius: 999, background: theme.colors.surfaceStrong, border: `1.5px solid ${theme.colors.border}`, fontFamily: theme.fonts.display, opacity: Math.min(1, p * 1.5), transform: `scale(${0.5 + 0.5 * p}) translateY(${(1 - p) * 30}px)` }}>
      <span style={{ fontSize: 36, color: theme.colors.textDim, fontWeight: 600 }}>Number</span>
      <GradText style={{ fontSize: 68, fontWeight: 700, lineHeight: 1.1 }}>{n}</GradText>
    </div>
  );
};

/* ================================================================ Icons (SVG, theme-colored) */
const PATHS: Record<string, string[]> = {
  spark: ["M12 3l1.9 5.1L19 10l-5.1 1.9L12 17l-1.9-5.1L5 10l5.1-1.9z", "M19 15l.8 2.2L22 18l-2.2.8L19 21l-.8-2.2L16 18l2.2-.8z"],
  check: ["M5 12.5l4.5 4.5L19 7.5"],
  lock: ["M6 11h12a1 1 0 0 1 1 1v7a1 1 0 0 1-1 1H6a1 1 0 0 1-1-1v-7a1 1 0 0 1 1-1z", "M8 11V8a4 4 0 0 1 8 0v3", "M12 15v2"],
  plane: ["M21 3L3 10.5l7 2.5 2.5 7z", "M10 13L21 3"],
  link: ["M10 14a4 4 0 0 0 5.7 0l3-3a4 4 0 0 0-5.7-5.7l-1 1", "M14 10a4 4 0 0 0-5.7 0l-3 3a4 4 0 0 0 5.7 5.7l1-1"],
  bell: ["M18 16v-5a6 6 0 0 0-12 0v5l-2 2h16z", "M10 21a2 2 0 0 0 4 0"],
  user: ["M12 12a4 4 0 1 0 0-8 4 4 0 0 0 0 8z", "M4 20a8 8 0 0 1 16 0"],
  userplus: ["M10 12a4 4 0 1 0 0-8 4 4 0 0 0 0 8z", "M2 20a8 8 0 0 1 16 0", "M19 8v6", "M16 11h6"],
  code: ["M8 7l-5 5 5 5", "M16 7l5 5-5 5", "M14 4l-4 16"],
  arrow: ["M5 12h14", "M13 6l6 6-6 6"],
  image: ["M4 5h16v14H4z", "M4 16l5-5 4 4 3-3 4 4", "M9 9.5a.6.6 0 1 0 .01 0"],
  type: ["M5 6V4h14v2", "M12 4v16", "M9 20h6"],
  layout: ["M3 4h18v16H3z", "M3 9h18", "M9 9v11"],
  tag: ["M3 12V4h8l10 10-8 8z", "M7.5 8h.01"],
  mic: ["M12 15a3 3 0 0 0 3-3V6a3 3 0 0 0-6 0v6a3 3 0 0 0 3 3z", "M6 11a6 6 0 0 0 12 0", "M12 17v4"],
  close: ["M6 6l12 12", "M18 6L6 18"],
  bolt: ["M13 2L4 14h7l-1 8 9-12h-7z"],
  hex: ["M12 2l8.5 5v10L12 22l-8.5-5V7z"],
  mail: ["M3 5h18v14H3z", "M3 6l9 7 9-7"],
  globe: ["M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18z", "M3 12h18", "M12 3a14 14 0 0 1 0 18 14 14 0 0 1 0-18"],
};
export const Icon: React.FC<{ name: keyof typeof PATHS | string; size?: number; color?: string; stroke?: number; style?: React.CSSProperties; draw?: number }> = ({ name, size = 48, color = theme.colors.text, stroke = 2, style, draw }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth={stroke} strokeLinecap="round" strokeLinejoin="round" style={style}>
    {PATHS[name].map((d, i) => <path key={i} d={d} pathLength={1} strokeDasharray={1} strokeDashoffset={draw === undefined ? 0 : 1 - draw} />)}
  </svg>
);

export const IconBadge: React.FC<{ name: string; size?: number; hero?: boolean; delay?: number }> = ({ name, size = 84, hero, delay }) => {
  const spr = useSpr();
  const p = delay === undefined ? 1 : spr(delay, theme.spring.bouncy);
  return (
    <div style={{ width: size, height: size, borderRadius: size * 0.3, display: "flex", alignItems: "center", justifyContent: "center", background: hero ? theme.gradient.hero : theme.colors.surfaceStrong, border: `1.5px solid ${hero ? "transparent" : theme.colors.border}`, boxShadow: hero ? `0 14px 44px ${theme.colors.glow}` : "none", transform: `scale(${0.4 + 0.6 * p})`, opacity: Math.min(1, p * 1.5) }}>
      <Icon name={name} size={size * 0.52} color={hero ? theme.colors.white : theme.colors.text} stroke={2.2} />
    </div>
  );
};

/* ================================================================ Cursor & press feedback */
export const Cursor: React.FC<{ x: number; y: number; press?: number; opacity?: number }> = ({ x, y, press = 0, opacity = 1 }) => (
  <div style={{ position: "absolute", left: x, top: y, opacity, transform: `scale(${1 - press * 0.16})`, transformOrigin: "0 0", filter: "drop-shadow(0 6px 10px rgba(0,0,0,0.5))", zIndex: 50 }}>
    <svg width="54" height="54" viewBox="0 0 24 24"><path d="M5 3l14 7-6 2-2 6z" fill={theme.colors.white} stroke={theme.colors.ink} strokeWidth="1.3" strokeLinejoin="round" /></svg>
  </div>
);
export const Ripple: React.FC<{ at: number; x: number; y: number; size?: number }> = ({ at, x, y, size = 220 }) => {
  const tw = useTween();
  const t = tw(at, at + 18, 0, 1);
  if (t <= 0 || t >= 1) return null;
  return <div style={{ position: "absolute", left: x - size / 2, top: y - size / 2, width: size, height: size, borderRadius: "50%", border: `3px solid ${theme.colors.accent}`, opacity: 1 - t, transform: `scale(${0.2 + t * 0.9})` }} />;
};

/* ================================================================ Scene shell with exit */
export const SceneShell: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { dur } = useScene();
  const frame = useCurrentFrame();
  const q = interpolate(frame, [dur - 10, dur - 1], [0, 1], { easing: theme.ease.in, ...CL });
  return <AbsoluteFill style={{ opacity: 1 - q * 0.9, transform: `scale(${1 + q * 0.05})` }}>{children}</AbsoluteFill>;
};

/* ================================================================ Preview-only voiceover */
export const PreviewAudio: React.FC = () => {
  const { isRendering } = getRemotionEnvironment();
  const active = VOICEOVER.enabled && (!isRendering || VOICEOVER.includeInRender);
  const [ok, setOk] = useState(false);
  const [handle] = useState(() => (active && isRendering ? delayRender("voiceover check") : null));
  useEffect(() => {
    if (!active) return;
    let alive = true;
    fetch(staticFile(VOICEOVER.file), { method: "HEAD" })
      .then((r) => { if (alive) setOk(r.ok && (r.headers.get("content-type") || "").includes("audio")); })
      .catch(() => alive && setOk(false))
      .finally(() => { if (handle !== null) continueRender(handle); });
    return () => { alive = false; };
  }, [active, handle]);
  if (!active || !ok) return null;
  return <Audio src={staticFile(VOICEOVER.file)} volume={VOICEOVER.volume} />;
};
