# AI Website Tools — Motion Graphics Video (Remotion)

1920×1080 · 30fps · ~59s · dark theme "Deep Space Blue"

    npm install                                              # once
    npx remotion studio                                      # live preview (composition: Main)
    npx remotion render src/index.ts Main out/video.mp4      # render MP4

- Voiceover preview: put your MP3 at `public/voiceover.mp3` (plays in Studio; excluded from renders by default — see `src/config.ts`).
- All timing comes from the SRT embedded in `src/script.ts` (scenes are defined by cue numbers in `src/timeline.ts`).
- Colors / easing / springs / font: `src/theme.ts`. SFX: `public/sfx/*.wav` (regenerate with `node scripts/make-sfx.mjs`).
