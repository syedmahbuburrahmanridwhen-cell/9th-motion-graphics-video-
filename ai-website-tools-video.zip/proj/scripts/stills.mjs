import { bundle } from "@remotion/bundler";
import { renderStill, selectComposition } from "@remotion/renderer";
import path from "node:path";
import fs from "node:fs";
const frames = process.argv.slice(2).map(Number);
const browserExecutable = process.env.BROWSER || undefined;
const serveUrl = await bundle({ entryPoint: path.resolve("src/index.ts"), onProgress: () => {} });
const comp = await selectComposition({ serveUrl, id: "Main", browserExecutable });
fs.mkdirSync("/tmp/stills", { recursive: true });
for (const f of frames) {
  await renderStill({ composition: comp, serveUrl, frame: f, output: `/tmp/stills/f${String(f).padStart(4, "0")}.png`, browserExecutable, imageFormat: "png" });
  console.log("ok", f);
}
