// Synthesizes a small, soft UI/motion SFX kit into public/sfx/*.wav (deterministic, zero downloads).
import fs from "node:fs";
import path from "node:path";
const SR = 44100;
const OUT = path.resolve("public/sfx");
fs.mkdirSync(OUT, { recursive: true });

let seed = 1337;
const rand = () => { seed = (seed * 1664525 + 1013904223) >>> 0; return seed / 4294967296 * 2 - 1; };

class Biquad {
  constructor(type, f, q = 0.707) { this.z1 = 0; this.z2 = 0; this.set(type, f, q); }
  set(type, f, q) {
    const w = 2 * Math.PI * f / SR, c = Math.cos(w), s = Math.sin(w), a = s / (2 * q);
    let b0, b1, b2, a0 = 1 + a, a1 = -2 * c, a2 = 1 - a;
    if (type === "lp") { b0 = (1 - c) / 2; b1 = 1 - c; b2 = (1 - c) / 2; }
    else if (type === "hp") { b0 = (1 + c) / 2; b1 = -(1 + c); b2 = (1 + c) / 2; }
    else { b0 = a; b1 = 0; b2 = -a; } // bp (constant 0 dB peak)
    this.b0 = b0 / a0; this.b1 = b1 / a0; this.b2 = b2 / a0; this.a1 = a1 / a0; this.a2 = a2 / a0;
  }
  p(x) { const y = this.b0 * x + this.z1; this.z1 = this.b1 * x - this.a1 * y + this.z2; this.z2 = this.b2 * x - this.a2 * y; return y; }
}
const N = (sec) => Math.floor(sec * SR);

function reverb(x, mix = 0.1) {
  const out = Float32Array.from(x);
  for (const d of [0.0297, 0.0371, 0.0411, 0.0437].map((v) => Math.floor(v * SR))) {
    const y = new Float32Array(x.length);
    for (let i = 0; i < x.length; i++) { y[i] = x[i] + (i >= d ? 0.36 * y[i - d] : 0); out[i] += (mix / 4) * y[i]; }
  }
  return out;
}
function finish(x, lp = 6500, fadeOut = 0.03) {
  const f = new Biquad("lp", lp, 0.6);
  const y = reverb(x, 0.1).map((v) => f.p(v));
  const fi = N(0.002), fo = N(fadeOut);
  for (let i = 0; i < y.length; i++) {
    if (i < fi) y[i] *= i / fi;
    const r = y.length - 1 - i; if (r < fo) y[i] *= Math.max(0, r / fo);
  }
  return y;
}

const pop = () => {
  const x = new Float32Array(N(0.24)); let ph = 0;
  for (let i = 0; i < x.length; i++) {
    const t = i / SR, f = 190 + 640 * Math.exp(-t * 40); ph += 2 * Math.PI * f / SR;
    const env = (1 - Math.exp(-t * 1100)) * Math.exp(-t * 24);
    x[i] = (Math.sin(ph) + 0.22 * Math.sin(2 * ph) * Math.exp(-t * 50)) * env;
  }
  return finish(x, 5200);
};
const click = () => {
  const x = new Float32Array(N(0.11)), hp = new Biquad("hp", 2600, 0.8), bp = new Biquad("bp", 4200, 1.2);
  for (let i = 0; i < x.length; i++) {
    const t = i / SR, n = bp.p(hp.p(rand()));
    x[i] = n * Math.exp(-t * 230) * (1 - Math.exp(-t * 3000)) + 0.35 * Math.sin(2 * Math.PI * 1500 * t) * Math.exp(-t * 380);
  }
  return finish(x, 7000, 0.02);
};
const whoosh = (len, f0, f1, q = 1.1) => () => {
  const x = new Float32Array(N(len)), bp = new Biquad("bp", f0, q);
  for (let i = 0; i < x.length; i++) {
    const t = i / SR, u = t / len;
    if (i % 32 === 0) bp.set("bp", f0 * Math.pow(f1 / f0, Math.pow(u, 0.8)), q);
    const env = Math.pow(Math.sin(Math.PI * Math.pow(u, 0.75)), 2);
    x[i] = bp.p(rand()) * env;
  }
  return finish(x, 6000, 0.05);
};
const chime = () => {
  const x = new Float32Array(N(0.5));
  const notes = [{ f: 880, at: 0, a: 1 }, { f: 1318.5, at: 0.07, a: 0.75 }];
  for (const n of notes) for (const [k, amp, tau] of [[1, 1, 0.16], [2.0, 0.3, 0.09], [3.01, 0.12, 0.05]]) {
    for (let i = Math.floor(n.at * SR); i < x.length; i++) {
      const t = (i - n.at * SR) / SR;
      x[i] += n.a * amp * Math.sin(2 * Math.PI * n.f * k * t) * (1 - Math.exp(-t * 900)) * Math.exp(-t / tau);
    }
  }
  return finish(x, 5200, 0.06);
};
const thud = () => {
  const x = new Float32Array(N(0.38)); let ph = 0;
  for (let i = 0; i < x.length; i++) {
    const t = i / SR, f = 46 + 80 * Math.exp(-t * 20); ph += 2 * Math.PI * f / SR;
    x[i] = Math.sin(ph) * (1 - Math.exp(-t * 260)) * Math.exp(-t * 11);
  }
  return finish(x, 240, 0.08);
};

const kit = { pop, click, whoosh: whoosh(0.7, 380, 3200), swipe: whoosh(0.5, 600, 5200, 1.4), chime, thud };
const TARGET_RMS = 0.14, PEAK = 0.88;
const report = [];
for (const [name, make] of Object.entries(kit)) {
  let x = make();
  let peak = 0, sum = 0; for (const v of x) { peak = Math.max(peak, Math.abs(v)); sum += v * v; }
  const rms = Math.sqrt(sum / x.length);
  const gain = Math.min(PEAK / peak, TARGET_RMS / rms);
  x = x.map((v) => v * gain);
  const pcm = Buffer.alloc(44 + x.length * 2);
  pcm.write("RIFF", 0); pcm.writeUInt32LE(36 + x.length * 2, 4); pcm.write("WAVEfmt ", 8);
  pcm.writeUInt32LE(16, 16); pcm.writeUInt16LE(1, 20); pcm.writeUInt16LE(1, 22); pcm.writeUInt32LE(SR, 24);
  pcm.writeUInt32LE(SR * 2, 28); pcm.writeUInt16LE(2, 32); pcm.writeUInt16LE(16, 34); pcm.write("data", 36); pcm.writeUInt32LE(x.length * 2, 40);
  x.forEach((v, i) => pcm.writeInt16LE(Math.max(-32768, Math.min(32767, Math.round(v * 32767))), 44 + i * 2));
  fs.writeFileSync(path.join(OUT, `${name}.wav`), pcm);
  report.push(name);
}
console.log("sfx written:", report.join(", "));
